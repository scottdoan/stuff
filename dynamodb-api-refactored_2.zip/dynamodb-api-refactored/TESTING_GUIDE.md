# Testing Guide

This document provides comprehensive information about the test suite for the DynamoDB REST API.

## Test Structure

```
src/test/java/com/example/dynamodbapi/
├── controller/
│   └── UserControllerTest.java      # REST API endpoint tests
├── service/
│   └── UserServiceTest.java         # Business logic tests
└── mapper/
    └── UserMapperTest.java          # Mapping logic tests
```

## Test Coverage

### Unit Tests Overview

| Component | Test Class | Tests | Coverage |
|-----------|------------|-------|----------|
| UserMapper | UserMapperTest | 6 tests | Model ↔ Entity conversion |
| UserService | UserServiceTest | 12 tests | Business logic operations |
| UserController | UserControllerTest | 10 tests | REST API endpoints |

**Total: 28 comprehensive unit tests**

## Testing Technologies

- **JUnit 5** (Jupiter) - Testing framework
- **Mockito** - Mocking framework
- **AssertJ** - Fluent assertions
- **Spring MockMvc** - Controller testing
- **Spring Boot Test** - Test utilities

## Running Tests

### Run All Tests
```bash
mvn test
```

### Run Specific Test Class
```bash
mvn test -Dtest=UserServiceTest
```

### Run Tests with Coverage
```bash
mvn test jacoco:report
```

### Run Tests in IDE
- **IntelliJ IDEA**: Right-click on test class → "Run Tests"
- **Eclipse**: Right-click on test class → "Run As" → "JUnit Test"

## Test Categories

### 1. Mapper Tests (UserMapperTest)

**Purpose**: Verify correct conversion between domain models and database entities

**Test Cases**:
1. ✅ Convert User to UserEntity successfully
2. ✅ Handle null User when converting to entity
3. ✅ Convert UserEntity to User successfully
4. ✅ Handle null UserEntity when converting to model
5. ✅ Handle User with null age field
6. ✅ Maintain data integrity during round-trip conversion

**Example**:
```java
@Test
@DisplayName("Should convert User domain model to UserEntity")
void testToEntity_Success() {
    User user = new User("123", "John Doe", "john@example.com", 30);
    UserEntity entity = userMapper.toEntity(user);
    
    assertThat(entity).isNotNull();
    assertThat(entity.getUserId()).isEqualTo("123");
    assertThat(entity.getName()).isEqualTo("John Doe");
}
```

### 2. Service Tests (UserServiceTest)

**Purpose**: Verify business logic without database dependency

**Test Cases**:
1. ✅ Create user with auto-generated ID
2. ✅ Create user with existing ID
3. ✅ Get user by ID successfully
4. ✅ Return empty when user not found by ID
5. ✅ Get all users
6. ✅ Return empty list when no users exist
7. ✅ Update user successfully
8. ✅ Return empty when updating non-existent user
9. ✅ Delete user successfully
10. ✅ Return false when deleting non-existent user

**Testing Strategy**:
- Mock the `UserRepository` interface
- Test business logic in isolation
- Verify correct repository method calls
- No database required

**Example**:
```java
@Test
@DisplayName("Should create user with generated ID when ID is null")
void testCreateUser_GeneratesId() {
    User userWithoutId = new User(null, "Jane", "jane@example.com", 25);
    when(userRepository.save(any())).thenAnswer(i -> i.getArgument(0));
    
    User createdUser = userService.createUser(userWithoutId);
    
    assertThat(createdUser.getId()).isNotNull();
    verify(userRepository, times(1)).save(any());
}
```

### 3. Controller Tests (UserControllerTest)

**Purpose**: Verify REST API endpoints and HTTP handling

**Test Cases**:
1. ✅ POST /api/users - Create user (201 Created)
2. ✅ GET /api/users/{id} - Get user by ID (200 OK)
3. ✅ GET /api/users/{id} - User not found (404 Not Found)
4. ✅ GET /api/users - Get all users (200 OK)
5. ✅ GET /api/users - Empty list (200 OK)
6. ✅ PUT /api/users/{id} - Update user (200 OK)
7. ✅ PUT /api/users/{id} - User not found (404 Not Found)
8. ✅ DELETE /api/users/{id} - Delete user (204 No Content)
9. ✅ DELETE /api/users/{id} - User not found (404 Not Found)

**Testing Strategy**:
- Use Spring MockMvc for HTTP testing
- Mock the `UserService` layer
- Verify HTTP status codes
- Verify JSON request/response bodies
- No actual server startup required

**Example**:
```java
@Test
@DisplayName("POST /api/users - Should create user successfully")
void testCreateUser_Success() throws Exception {
    User newUser = new User(null, "Jane", "jane@example.com", 25);
    User createdUser = new User("456", "Jane", "jane@example.com", 25);
    when(userService.createUser(any())).thenReturn(createdUser);

    mockMvc.perform(post("/api/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(newUser)))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.id").value("456"))
        .andExpect(jsonPath("$.name").value("Jane"));
}
```

## Test Best Practices Demonstrated

### 1. Descriptive Test Names
```java
@Test
@DisplayName("Should return empty when user not found by ID")
void testGetUserById_NotFound() { ... }
```

### 2. Given-When-Then Pattern
```java
// Given - Setup test data and mocks
User testUser = new User("123", "John", "john@example.com", 30);
when(repository.findById("123")).thenReturn(Optional.of(testUser));

// When - Execute the code under test
Optional<User> result = service.getUserById("123");

// Then - Verify the results
assertThat(result).isPresent();
verify(repository, times(1)).findById("123");
```

### 3. Fluent Assertions with AssertJ
```java
assertThat(result)
    .isPresent()
    .hasValueSatisfying(user -> {
        assertThat(user.getId()).isEqualTo("123");
        assertThat(user.getName()).isEqualTo("John Doe");
    });
```

### 4. Isolation with Mocks
```java
@Mock
private UserRepository userRepository;

@InjectMocks
private UserService userService;
```

### 5. Comprehensive Edge Cases
- Null inputs
- Empty collections
- Non-existent resources
- Boundary conditions

## Benefits of This Test Suite

### ✅ Fast Execution
- No database required
- All tests run in memory
- Complete suite runs in seconds

### ✅ Maintainable
- Clear test names
- Well-organized structure
- Easy to add new tests

### ✅ Database-Independent
- Tests work regardless of database choice
- Can switch from DynamoDB to MySQL without changing tests
- Mocks abstract away infrastructure

### ✅ Comprehensive Coverage
- All CRUD operations tested
- Success and failure cases covered
- Edge cases handled

### ✅ Documentation
- Tests serve as usage examples
- DisplayName annotations explain intent
- Code is self-documenting

## Adding New Tests

### For New Features
1. Create test class in appropriate package
2. Add `@DisplayName` to describe the test suite
3. Use `@BeforeEach` for common setup
4. Write tests following Given-When-Then pattern
5. Use descriptive method names

### Example Template
```java
@ExtendWith(MockitoExtension.class)
@DisplayName("MyFeature Tests")
class MyFeatureTest {

    @Mock
    private SomeDependency dependency;

    @InjectMocks
    private MyFeature feature;

    @BeforeEach
    void setUp() {
        // Common setup
    }

    @Test
    @DisplayName("Should do something when condition is met")
    void testSomething() {
        // Given
        // ... setup
        
        // When
        // ... execute
        
        // Then
        // ... verify
    }
}
```

## Continuous Integration

### GitHub Actions Example
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up JDK 21
        uses: actions/setup-java@v2
        with:
          java-version: '21'
      - name: Run tests
        run: mvn test
```

### Maven Integration
Tests automatically run during:
- `mvn test` - Run tests only
- `mvn verify` - Run tests and integration tests
- `mvn install` - Full build including tests
- `mvn package` - Package with tests

## Code Coverage

To generate code coverage reports:

```bash
mvn clean test jacoco:report
```

View report at: `target/site/jacoco/index.html`

## Common Testing Patterns

### Testing Optional Returns
```java
// Present case
assertThat(result).isPresent();
assertThat(result.get().getId()).isEqualTo("123");

// Empty case
assertThat(result).isEmpty();
```

### Testing Lists
```java
assertThat(users).hasSize(2);
assertThat(users).containsExactly(user1, user2);
assertThat(users).extracting("name").containsExactly("John", "Jane");
```

### Testing Exceptions
```java
@Test
void shouldThrowException() {
    assertThatThrownBy(() -> service.doSomething(null))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("Parameter cannot be null");
}
```

### Verifying Mock Interactions
```java
// Verify method called once
verify(repository, times(1)).save(any());

// Verify method never called
verify(repository, never()).delete(any());

// Verify with specific arguments
verify(repository).findById(eq("123"));
```

## Troubleshooting Tests

### Test Fails with NullPointerException
- Check that all `@Mock` dependencies are injected
- Verify `@InjectMocks` is on the class under test
- Ensure mocks are configured with `when(...).thenReturn(...)`

### MockMvc Returns 404
- Verify `@WebMvcTest(YourController.class)` annotation
- Check request mapping path matches exactly
- Ensure controller method has correct HTTP method annotation

### Mock Not Working
- Verify import is `org.mockito.Mock`, not other Mock annotations
- Check test class has `@ExtendWith(MockitoExtension.class)`
- Ensure mock is configured before calling the method

## Further Reading

- [JUnit 5 User Guide](https://junit.org/junit5/docs/current/user-guide/)
- [Mockito Documentation](https://javadoc.io/doc/org.mockito/mockito-core/latest/)
- [AssertJ Documentation](https://assertj.github.io/doc/)
- [Spring Boot Testing](https://docs.spring.io/spring-boot/docs/current/reference/html/features.html#features.testing)
