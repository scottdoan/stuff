package com.example.dynamodbapi.mapper;

import com.example.dynamodbapi.entity.UserEntity;
import com.example.dynamodbapi.model.User;
import org.springframework.stereotype.Component;

/**
 * Mapper component for converting between domain models and database entities.
 * <p>
 * This mapper serves as the translation layer between the database-agnostic
 * domain model ({@link User}) and the DynamoDB-specific entity ({@link UserEntity}).
 * It ensures that the domain layer remains decoupled from infrastructure concerns.
 * </p>
 * <p>
 * This pattern allows the application to easily switch between different
 * persistence technologies without affecting the business logic layer.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@Component
public class UserMapper {

    /**
     * Converts a domain model User to a DynamoDB entity UserEntity.
     * <p>
     * This method maps the generic 'id' field in the domain model to
     * the 'userId' field in the DynamoDB entity, along with all other
     * common attributes.
     * </p>
     *
     * @param user the domain model to convert; may be null
     * @return the corresponding UserEntity, or null if the input is null
     */
    public UserEntity toEntity(User user) {
        if (user == null) {
            return null;
        }
        
        UserEntity entity = new UserEntity();
        entity.setUserId(user.getId());
        entity.setName(user.getName());
        entity.setEmail(user.getEmail());
        entity.setAge(user.getAge());
        return entity;
    }

    /**
     * Converts a DynamoDB entity UserEntity to a domain model User.
     * <p>
     * This method maps the DynamoDB-specific 'userId' field to the
     * generic 'id' field in the domain model, along with all other
     * common attributes.
     * </p>
     *
     * @param entity the DynamoDB entity to convert; may be null
     * @return the corresponding User domain model, or null if the input is null
     */
    public User toModel(UserEntity entity) {
        if (entity == null) {
            return null;
        }
        
        User user = new User();
        user.setId(entity.getUserId());
        user.setName(entity.getName());
        user.setEmail(entity.getEmail());
        user.setAge(entity.getAge());
        return user;
    }
}
