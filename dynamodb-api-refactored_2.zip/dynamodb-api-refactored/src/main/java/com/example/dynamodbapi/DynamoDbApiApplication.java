package com.example.dynamodbapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the DynamoDB REST API Spring Boot application.
 * <p>
 * This application demonstrates a clean architecture approach with:
 * <ul>
 *   <li>Separation of domain models from database entities</li>
 *   <li>Repository pattern for data access abstraction</li>
 *   <li>Service layer for business logic</li>
 *   <li>RESTful controllers for API endpoints</li>
 * </ul>
 * </p>
 * <p>
 * The architecture allows easy switching between different database
 * technologies without affecting business logic or API layers.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@SpringBootApplication
public class DynamoDbApiApplication {

    /**
     * Main method to start the Spring Boot application.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(DynamoDbApiApplication.class, args);
    }
}
