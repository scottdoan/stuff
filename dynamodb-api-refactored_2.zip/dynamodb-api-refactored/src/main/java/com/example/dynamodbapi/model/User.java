package com.example.dynamodbapi.model;

/**
 * Domain model representing a User entity in the system.
 * <p>
 * This is a database-agnostic POJO (Plain Old Java Object) that represents
 * the core business concept of a User. It contains no database-specific
 * annotations or dependencies, making it portable across different
 * persistence technologies.
 * </p>
 * <p>
 * This class follows the principles of Clean Architecture by separating
 * the domain model from infrastructure concerns.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
public class User {
    
    /**
     * Unique identifier for the user.
     * This is a generic ID field that maps to different database-specific
     * identifiers (e.g., userId in DynamoDB, id in MySQL).
     */
    private String id;
    
    /**
     * Full name of the user.
     */
    private String name;
    
    /**
     * Email address of the user.
     */
    private String email;
    
    /**
     * Age of the user in years.
     */
    private Integer age;

    /**
     * Default constructor required for frameworks and serialization.
     */
    public User() {
    }

    /**
     * Constructs a new User with the specified details.
     *
     * @param id    the unique identifier for the user
     * @param name  the full name of the user
     * @param email the email address of the user
     * @param age   the age of the user in years
     */
    public User(String id, String name, String email, Integer age) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.age = age;
    }

    /**
     * Gets the unique identifier of the user.
     *
     * @return the user's unique identifier
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the unique identifier of the user.
     *
     * @param id the unique identifier to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the name of the user.
     *
     * @return the user's name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the user.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the email address of the user.
     *
     * @return the user's email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the age of the user.
     *
     * @return the user's age in years
     */
    public Integer getAge() {
        return age;
    }

    /**
     * Sets the age of the user.
     *
     * @param age the age to set in years
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * Returns a string representation of the User.
     *
     * @return a string containing all user properties
     */
    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", age=" + age +
                '}';
    }
}
