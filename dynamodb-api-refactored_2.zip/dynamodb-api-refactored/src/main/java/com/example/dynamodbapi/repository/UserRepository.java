package com.example.dynamodbapi.repository;

import com.example.dynamodbapi.model.User;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for User data access operations.
 * <p>
 * This interface defines the contract for User persistence operations
 * without specifying the underlying database technology. Implementations
 * can use different persistence mechanisms (DynamoDB, MySQL, PostgreSQL,
 * MongoDB, etc.) without affecting the business logic layer.
 * </p>
 * <p>
 * This follows the Repository pattern and Dependency Inversion Principle,
 * allowing high-level modules to depend on this abstraction rather than
 * concrete implementations.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 * @see com.example.dynamodbapi.repository.DynamoDbUserRepository
 */
public interface UserRepository {
    
    /**
     * Saves a user to the data store.
     * <p>
     * If the user does not have an ID, a new one may be generated.
     * If the user already exists, it will be updated.
     * </p>
     *
     * @param user the user to save; must not be null
     * @return the saved user with any generated fields populated
     * @throws IllegalArgumentException if user is null
     */
    User save(User user);
    
    /**
     * Retrieves a user by their unique identifier.
     *
     * @param id the unique identifier of the user; must not be null
     * @return an Optional containing the user if found, empty otherwise
     * @throws IllegalArgumentException if id is null
     */
    Optional<User> findById(String id);
    
    /**
     * Retrieves all users from the data store.
     * <p>
     * Note: For production use with large datasets, consider implementing
     * pagination to avoid loading all records into memory.
     * </p>
     *
     * @return a list of all users; never null but may be empty
     */
    List<User> findAll();
    
    /**
     * Deletes a user by their unique identifier.
     *
     * @param id the unique identifier of the user to delete; must not be null
     * @throws IllegalArgumentException if id is null
     */
    void deleteById(String id);
    
    /**
     * Updates an existing user in the data store.
     * <p>
     * The user must have a valid ID. All fields will be updated.
     * </p>
     *
     * @param user the user with updated information; must not be null and must have an ID
     * @return the updated user
     * @throws IllegalArgumentException if user is null or has no ID
     */
    User update(User user);
}
