package com.example.dynamodbapi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

import java.net.URI;

/**
 * Configuration class for AWS DynamoDB client beans.
 * <p>
 * This configuration sets up the necessary DynamoDB clients for the application.
 * It configures both the standard DynamoDB client and the Enhanced Client,
 * which provides a higher-level abstraction for working with DynamoDB.
 * </p>
 * <p>
 * The configuration uses properties from {@code application.properties} to
 * specify the DynamoDB endpoint and AWS region. This allows easy switching
 * between production AWS DynamoDB and local DynamoDB for development.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@Configuration
public class DynamoDBConfig {

    @Value("${aws.dynamodb.endpoint}")
    private String dynamoDbEndpoint;

    @Value("${aws.dynamodb.region}")
    private String awsRegion;

    /**
     * Creates and configures the DynamoDB client bean.
     * <p>
     * The client is configured with:
     * <ul>
     *   <li>AWS region from application properties</li>
     *   <li>Endpoint override for local development or specific endpoints</li>
     *   <li>Default credentials provider chain for authentication</li>
     * </ul>
     * The default credentials provider checks multiple sources in order:
     * <ol>
     *   <li>Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)</li>
     *   <li>System properties (aws.accessKeyId, aws.secretAccessKey)</li>
     *   <li>AWS credentials file (~/.aws/credentials)</li>
     *   <li>IAM role for EC2 instances or ECS tasks</li>
     * </ol>
     * </p>
     *
     * @return configured DynamoDB client
     */
    @Bean
    public DynamoDbClient dynamoDbClient() {
        return DynamoDbClient.builder()
                .region(Region.of(awsRegion))
                .endpointOverride(URI.create(dynamoDbEndpoint))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    /**
     * Creates and configures the DynamoDB Enhanced Client bean.
     * <p>
     * The Enhanced Client provides a higher-level abstraction over the
     * standard DynamoDB client, with features like:
     * <ul>
     *   <li>Automatic mapping between Java objects and DynamoDB items</li>
     *   <li>Type-safe operations</li>
     *   <li>Simplified API for common operations</li>
     * </ul>
     * </p>
     *
     * @param dynamoDbClient the standard DynamoDB client; injected by Spring
     * @return configured DynamoDB Enhanced Client
     */
    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(DynamoDbClient dynamoDbClient) {
        return DynamoDbEnhancedClient.builder()
                .dynamoDbClient(dynamoDbClient)
                .build();
    }
}
