package com.example.dynamodbapi.service;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Service layer for User business logic operations.
 * <p>
 * This service provides business logic for managing users, including
 * CRUD operations and ID generation. It acts as an intermediary between
 * the controller layer and the repository layer, ensuring separation
 * of concerns.
 * </p>
 * <p>
 * The service layer is database-agnostic and works exclusively with
 * domain models ({@link User}), maintaining independence from the
 * underlying persistence technology.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@Service
public class UserService {

    private final UserRepository userRepository;

    /**
     * Constructs a new UserService with the specified repository.
     * <p>
     * Spring will automatically inject the appropriate repository
     * implementation (e.g., DynamoDbUserRepository).
     * </p>
     *
     * @param userRepository the repository for user data access; must not be null
     */
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Creates a new user in the system.
     * <p>
     * If the user does not have an ID, a UUID will be automatically
     * generated before saving.
     * </p>
     *
     * @param user the user to create; must not be null
     * @return the created user with ID populated
     * @throws IllegalArgumentException if user is null
     */
    public User createUser(User user) {
        if (user.getId() == null || user.getId().isEmpty()) {
            user.setId(UUID.randomUUID().toString());
        }
        return userRepository.save(user);
    }

    /**
     * Retrieves a user by their unique identifier.
     *
     * @param id the unique identifier of the user; must not be null or empty
     * @return an Optional containing the user if found, empty otherwise
     * @throws IllegalArgumentException if id is null or empty
     */
    public Optional<User> getUserById(String id) {
        return userRepository.findById(id);
    }

    /**
     * Retrieves all users in the system.
     * <p>
     * Note: This method loads all users into memory. For production
     * systems with large datasets, consider implementing pagination.
     * </p>
     *
     * @return a list of all users; never null but may be empty
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Updates an existing user's information.
     * <p>
     * This method first verifies the user exists, then updates
     * their name, email, and age with the provided values.
     * </p>
     *
     * @param id          the unique identifier of the user to update; must not be null
     * @param userDetails the user object containing updated information; must not be null
     * @return an Optional containing the updated user if found, empty otherwise
     * @throws IllegalArgumentException if id or userDetails is null
     */
    public Optional<User> updateUser(String id, User userDetails) {
        return userRepository.findById(id).map(existingUser -> {
            existingUser.setName(userDetails.getName());
            existingUser.setEmail(userDetails.getEmail());
            existingUser.setAge(userDetails.getAge());
            return userRepository.update(existingUser);
        });
    }

    /**
     * Deletes a user from the system.
     * <p>
     * This method first checks if the user exists before attempting deletion.
     * </p>
     *
     * @param id the unique identifier of the user to delete; must not be null
     * @return true if the user was found and deleted, false otherwise
     * @throws IllegalArgumentException if id is null
     */
    public boolean deleteUser(String id) {
        return userRepository.findById(id).map(user -> {
            userRepository.deleteById(id);
            return true;
        }).orElse(false);
    }
}
