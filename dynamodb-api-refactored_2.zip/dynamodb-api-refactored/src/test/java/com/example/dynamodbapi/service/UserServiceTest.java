package com.example.dynamodbapi.service;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link UserService}.
 * <p>
 * These tests verify the business logic layer using mocked repositories,
 * ensuring the service layer works correctly without requiring a database.
 * </p>
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("UserService Tests")
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User("123", "John Doe", "john@example.com", 30);
    }

    @Test
    @DisplayName("Should create user with generated ID when ID is null")
    void testCreateUser_GeneratesId() {
        // Given
        User userWithoutId = new User(null, "Jane Smith", "jane@example.com", 25);
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        User createdUser = userService.createUser(userWithoutId);

        // Then
        assertThat(createdUser.getId()).isNotNull();
        assertThat(createdUser.getId()).isNotEmpty();
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    @DisplayName("Should create user with existing ID")
    void testCreateUser_WithExistingId() {
        // Given
        when(userRepository.save(testUser)).thenReturn(testUser);

        // When
        User createdUser = userService.createUser(testUser);

        // Then
        assertThat(createdUser).isNotNull();
        assertThat(createdUser.getId()).isEqualTo("123");
        verify(userRepository, times(1)).save(testUser);
    }

    @Test
    @DisplayName("Should get user by ID successfully")
    void testGetUserById_Success() {
        // Given
        when(userRepository.findById("123")).thenReturn(Optional.of(testUser));

        // When
        Optional<User> result = userService.getUserById("123");

        // Then
        assertThat(result).isPresent();
        assertThat(result.get().getId()).isEqualTo("123");
        assertThat(result.get().getName()).isEqualTo("John Doe");
        verify(userRepository, times(1)).findById("123");
    }

    @Test
    @DisplayName("Should return empty when user not found by ID")
    void testGetUserById_NotFound() {
        // Given
        when(userRepository.findById("999")).thenReturn(Optional.empty());

        // When
        Optional<User> result = userService.getUserById("999");

        // Then
        assertThat(result).isEmpty();
        verify(userRepository, times(1)).findById("999");
    }

    @Test
    @DisplayName("Should get all users")
    void testGetAllUsers() {
        // Given
        User user2 = new User("456", "Jane Smith", "jane@example.com", 25);
        List<User> users = Arrays.asList(testUser, user2);
        when(userRepository.findAll()).thenReturn(users);

        // When
        List<User> result = userService.getAllUsers();

        // Then
        assertThat(result).hasSize(2);
        assertThat(result).containsExactly(testUser, user2);
        verify(userRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no users exist")
    void testGetAllUsers_EmptyList() {
        // Given
        when(userRepository.findAll()).thenReturn(List.of());

        // When
        List<User> result = userService.getAllUsers();

        // Then
        assertThat(result).isEmpty();
        verify(userRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should update user successfully")
    void testUpdateUser_Success() {
        // Given
        User updatedDetails = new User(null, "John Updated", "john.updated@example.com", 31);
        User expectedUser = new User("123", "John Updated", "john.updated@example.com", 31);
        
        when(userRepository.findById("123")).thenReturn(Optional.of(testUser));
        when(userRepository.update(any(User.class))).thenReturn(expectedUser);

        // When
        Optional<User> result = userService.updateUser("123", updatedDetails);

        // Then
        assertThat(result).isPresent();
        assertThat(result.get().getName()).isEqualTo("John Updated");
        assertThat(result.get().getEmail()).isEqualTo("john.updated@example.com");
        assertThat(result.get().getAge()).isEqualTo(31);
        verify(userRepository, times(1)).findById("123");
        verify(userRepository, times(1)).update(any(User.class));
    }

    @Test
    @DisplayName("Should return empty when updating non-existent user")
    void testUpdateUser_NotFound() {
        // Given
        User updatedDetails = new User(null, "John Updated", "john.updated@example.com", 31);
        when(userRepository.findById("999")).thenReturn(Optional.empty());

        // When
        Optional<User> result = userService.updateUser("999", updatedDetails);

        // Then
        assertThat(result).isEmpty();
        verify(userRepository, times(1)).findById("999");
        verify(userRepository, never()).update(any(User.class));
    }

    @Test
    @DisplayName("Should delete user successfully")
    void testDeleteUser_Success() {
        // Given
        when(userRepository.findById("123")).thenReturn(Optional.of(testUser));
        doNothing().when(userRepository).deleteById("123");

        // When
        boolean result = userService.deleteUser("123");

        // Then
        assertThat(result).isTrue();
        verify(userRepository, times(1)).findById("123");
        verify(userRepository, times(1)).deleteById("123");
    }

    @Test
    @DisplayName("Should return false when deleting non-existent user")
    void testDeleteUser_NotFound() {
        // Given
        when(userRepository.findById("999")).thenReturn(Optional.empty());

        // When
        boolean result = userService.deleteUser("999");

        // Then
        assertThat(result).isFalse();
        verify(userRepository, times(1)).findById("999");
        verify(userRepository, never()).deleteById(anyString());
    }
}
