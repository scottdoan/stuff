package com.example.dynamodbapi.controller;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for {@link UserController}.
 * <p>
 * These tests verify the REST API layer using Spring's MockMvc framework,
 * ensuring proper HTTP request/response handling without starting a full server.
 * </p>
 */
@WebMvcTest(UserController.class)
@DisplayName("UserController Tests")
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User("123", "John Doe", "john@example.com", 30);
    }

    @Test
    @DisplayName("POST /api/users - Should create user successfully")
    void testCreateUser_Success() throws Exception {
        // Given
        User newUser = new User(null, "Jane Smith", "jane@example.com", 25);
        User createdUser = new User("456", "Jane Smith", "jane@example.com", 25);
        when(userService.createUser(any(User.class))).thenReturn(createdUser);

        // When & Then
        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newUser)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value("456"))
                .andExpect(jsonPath("$.name").value("Jane Smith"))
                .andExpect(jsonPath("$.email").value("jane@example.com"))
                .andExpect(jsonPath("$.age").value(25));

        verify(userService, times(1)).createUser(any(User.class));
    }

    @Test
    @DisplayName("GET /api/users/{id} - Should get user by ID successfully")
    void testGetUserById_Success() throws Exception {
        // Given
        when(userService.getUserById("123")).thenReturn(Optional.of(testUser));

        // When & Then
        mockMvc.perform(get("/api/users/123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("123"))
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john@example.com"))
                .andExpect(jsonPath("$.age").value(30));

        verify(userService, times(1)).getUserById("123");
    }

    @Test
    @DisplayName("GET /api/users/{id} - Should return 404 when user not found")
    void testGetUserById_NotFound() throws Exception {
        // Given
        when(userService.getUserById("999")).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(get("/api/users/999"))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).getUserById("999");
    }

    @Test
    @DisplayName("GET /api/users - Should get all users")
    void testGetAllUsers() throws Exception {
        // Given
        User user2 = new User("456", "Jane Smith", "jane@example.com", 25);
        List<User> users = Arrays.asList(testUser, user2);
        when(userService.getAllUsers()).thenReturn(users);

        // When & Then
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id").value("123"))
                .andExpect(jsonPath("$[0].name").value("John Doe"))
                .andExpect(jsonPath("$[1].id").value("456"))
                .andExpect(jsonPath("$[1].name").value("Jane Smith"));

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    @DisplayName("GET /api/users - Should return empty list when no users exist")
    void testGetAllUsers_EmptyList() throws Exception {
        // Given
        when(userService.getAllUsers()).thenReturn(List.of());

        // When & Then
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));

        verify(userService, times(1)).getAllUsers();
    }

    @Test
    @DisplayName("PUT /api/users/{id} - Should update user successfully")
    void testUpdateUser_Success() throws Exception {
        // Given
        User updatedUser = new User("123", "John Updated", "john.updated@example.com", 31);
        when(userService.updateUser(eq("123"), any(User.class))).thenReturn(Optional.of(updatedUser));

        // When & Then
        mockMvc.perform(put("/api/users/123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("123"))
                .andExpect(jsonPath("$.name").value("John Updated"))
                .andExpect(jsonPath("$.email").value("john.updated@example.com"))
                .andExpect(jsonPath("$.age").value(31));

        verify(userService, times(1)).updateUser(eq("123"), any(User.class));
    }

    @Test
    @DisplayName("PUT /api/users/{id} - Should return 404 when updating non-existent user")
    void testUpdateUser_NotFound() throws Exception {
        // Given
        User updatedUser = new User("999", "John Updated", "john.updated@example.com", 31);
        when(userService.updateUser(eq("999"), any(User.class))).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(put("/api/users/999")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedUser)))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).updateUser(eq("999"), any(User.class));
    }

    @Test
    @DisplayName("DELETE /api/users/{id} - Should delete user successfully")
    void testDeleteUser_Success() throws Exception {
        // Given
        when(userService.deleteUser("123")).thenReturn(true);

        // When & Then
        mockMvc.perform(delete("/api/users/123"))
                .andExpect(status().isNoContent());

        verify(userService, times(1)).deleteUser("123");
    }

    @Test
    @DisplayName("DELETE /api/users/{id} - Should return 404 when deleting non-existent user")
    void testDeleteUser_NotFound() throws Exception {
        // Given
        when(userService.deleteUser("999")).thenReturn(false);

        // When & Then
        mockMvc.perform(delete("/api/users/999"))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).deleteUser("999");
    }
}
