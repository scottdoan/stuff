# GraphQL Migration Guide

## Overview

This guide explains how to add GraphQL to your Spring Boot DynamoDB API or switch from REST to GraphQL.

## What Changed?

The beauty of our clean architecture is that **adding GraphQL requires NO changes to existing code**:
- ✅ Service layer unchanged
- ✅ Repository layer unchanged
- ✅ Domain models unchanged
- ✅ Database entities unchanged
- ✅ Mapper unchanged

**Only additions:**
- ➕ GraphQL dependencies in pom.xml
- ➕ GraphQL schema file
- ➕ GraphQL controller (resolver)
- ➕ Input DTOs for GraphQL

## Architecture Comparison

### REST Architecture
```
HTTP Request → REST Controller → Service → Repository → Database
                     ↓
              User (domain model)
```

### GraphQL Architecture
```
GraphQL Request → GraphQL Controller → Service → Repository → Database
                        ↓
                 User (domain model)
```

**Both share the same Service layer!** This is the power of clean architecture.

## Step-by-Step Migration

### Option 1: Keep Both REST and GraphQL (Recommended)

This allows clients to choose their preferred API style.

#### Step 1: Add Dependencies

Add to `pom.xml`:

```xml
<!-- Spring Boot GraphQL -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>

<!-- GraphQL Java Extended Scalars -->
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-java-extended-scalars</artifactId>
    <version>21.0</version>
</dependency>
```

#### Step 2: Create GraphQL Schema

Create `src/main/resources/graphql/schema.graphqls`:

```graphql
type User {
    id: ID!
    name: String!
    email: String!
    age: Int
}

input CreateUserInput {
    name: String!
    email: String!
    age: Int
}

input UpdateUserInput {
    name: String
    email: String
    age: Int
}

type Query {
    user(id: ID!): User
    users: [User!]!
    searchUsers(name: String!): [User!]!
}

type Mutation {
    createUser(input: CreateUserInput!): User!
    updateUser(id: ID!, input: UpdateUserInput!): User
    deleteUser(id: ID!): Boolean!
}
```

#### Step 3: Create Input DTOs

Create `CreateUserInput.java` and `UpdateUserInput.java` (see files in project).

#### Step 4: Create GraphQL Controller

Create `UserGraphQLController.java`:

```java
@Controller
public class UserGraphQLController {
    
    private final UserService userService;
    
    public UserGraphQLController(UserService userService) {
        this.userService = userService;
    }
    
    @QueryMapping
    public User user(@Argument String id) {
        return userService.getUserById(id).orElse(null);
    }
    
    @QueryMapping
    public List<User> users() {
        return userService.getAllUsers();
    }
    
    @MutationMapping
    public User createUser(@Argument CreateUserInput input) {
        User user = new User();
        user.setName(input.getName());
        user.setEmail(input.getEmail());
        user.setAge(input.getAge());
        return userService.createUser(user);
    }
    
    // ... other methods
}
```

#### Step 5: Configure GraphQL

Add to `application.properties`:

```properties
# GraphQL Configuration
spring.graphql.graphiql.enabled=true
spring.graphql.graphiql.path=/graphiql
spring.graphql.path=/graphql
```

#### Step 6: Run and Test

```bash
mvn spring-boot:run
```

**Access Points:**
- REST API: `http://localhost:8080/api/users`
- GraphQL: `http://localhost:8080/graphql`
- GraphiQL (UI): `http://localhost:8080/graphiql`

**Both APIs work simultaneously!**

### Option 2: Replace REST with GraphQL Only

If you want to completely replace REST:

1. Follow Steps 1-5 above
2. Delete or comment out `UserController.java`
3. Optionally remove `spring-boot-starter-web` if only using GraphQL

**Note:** Most applications keep both for flexibility.

## Using GraphQL

### GraphiQL Interface

Open `http://localhost:8080/graphiql` in your browser for an interactive GraphQL playground.

### Example Queries

#### Get All Users
```graphql
query {
  users {
    id
    name
    email
    age
  }
}
```

#### Get Single User
```graphql
query {
  user(id: "123") {
    id
    name
    email
    age
  }
}
```

#### Search Users by Name
```graphql
query {
  searchUsers(name: "john") {
    id
    name
    email
  }
}
```

#### Selective Fields (GraphQL Advantage!)
```graphql
query {
  users {
    name
    email
  }
}
```
**Returns only name and email - reduces data transfer!**

### Example Mutations

#### Create User
```graphql
mutation {
  createUser(input: {
    name: "John Doe"
    email: "john@example.com"
    age: 30
  }) {
    id
    name
    email
    age
  }
}
```

#### Update User
```graphql
mutation {
  updateUser(id: "123", input: {
    name: "John Updated"
    email: "john.updated@example.com"
  }) {
    id
    name
    email
    age
  }
}
```

#### Delete User
```graphql
mutation {
  deleteUser(id: "123")
}
```

## Using cURL with GraphQL

### Query Example
```bash
curl -X POST http://localhost:8080/graphql \
  -H "Content-Type: application/json" \
  -d '{
    "query": "{ users { id name email } }"
  }'
```

### Mutation Example
```bash
curl -X POST http://localhost:8080/graphql \
  -H "Content-Type: application/json" \
  -d '{
    "query": "mutation($input: CreateUserInput!) { createUser(input: $input) { id name email } }",
    "variables": {
      "input": {
        "name": "Jane Smith",
        "email": "jane@example.com",
        "age": 25
      }
    }
  }'
```

## REST vs GraphQL Comparison

### Get User by ID

**REST:**
```bash
GET /api/users/123
```
Returns all fields always.

**GraphQL:**
```graphql
query {
  user(id: "123") {
    name
    email
  }
}
```
Returns only requested fields.

### Get Multiple Resources

**REST:** Multiple requests needed
```bash
GET /api/users/123
GET /api/users/456
GET /api/users/789
```

**GraphQL:** Single request
```graphql
query {
  user1: user(id: "123") { name }
  user2: user(id: "456") { name }
  user3: user(id: "789") { name }
}
```

### Create User

**REST:**
```bash
POST /api/users
{ "name": "John", "email": "john@example.com", "age": 30 }
```

**GraphQL:**
```graphql
mutation {
  createUser(input: { name: "John", email: "john@example.com", age: 30 }) {
    id
    name
  }
}
```

## GraphQL Advantages

✅ **No Over-fetching**: Client requests only needed fields  
✅ **No Under-fetching**: Single request for multiple resources  
✅ **Strongly Typed**: Schema provides clear API contract  
✅ **Self-Documenting**: Schema serves as documentation  
✅ **Versioning Not Needed**: Add fields without breaking clients  
✅ **Developer Tools**: GraphiQL provides excellent dev experience  

## REST Advantages

✅ **Simpler Caching**: HTTP caching works out of the box  
✅ **Wider Adoption**: More developers familiar with REST  
✅ **Better for File Uploads**: REST handles files better  
✅ **HTTP Status Codes**: Clear success/error indication  

## When to Use Each

### Use REST when:
- Building simple CRUD APIs
- HTTP caching is critical
- Team is unfamiliar with GraphQL
- File uploads are primary use case

### Use GraphQL when:
- Mobile apps need flexible data fetching
- Complex nested data relationships
- Multiple clients need different data shapes
- Real-time updates needed (subscriptions)

### Use Both when:
- **Recommended for most applications**
- Different clients have different needs
- Gradual migration from REST to GraphQL
- Maximum flexibility

## Project Structure with GraphQL

```
src/main/java/com/example/dynamodbapi/
├── model/                      # Domain Models (shared)
│   └── User.java
├── entity/                     # Database Entities (shared)
│   └── UserEntity.java
├── mapper/                     # Mappers (shared)
│   └── UserMapper.java
├── repository/                 # Repositories (shared)
│   ├── UserRepository.java
│   └── DynamoDbUserRepository.java
├── service/                    # Services (shared)
│   └── UserService.java
├── controller/                 # REST Controllers
│   └── UserController.java
└── graphql/                    # GraphQL Components
    ├── UserGraphQLController.java
    ├── CreateUserInput.java
    └── UpdateUserInput.java
```

**Notice:** Only controller/graphql layers differ. Everything else is shared!

## Testing GraphQL

### Unit Tests

GraphQL controllers can be tested like REST controllers:

```java
@GraphQlTest(UserGraphQLController.class)
class UserGraphQLControllerTest {
    
    @Autowired
    private GraphQlTester graphQlTester;
    
    @MockBean
    private UserService userService;
    
    @Test
    void shouldGetUser() {
        User user = new User("123", "John", "john@example.com", 30);
        when(userService.getUserById("123")).thenReturn(Optional.of(user));
        
        graphQlTester
            .documentName("getUser")
            .variable("id", "123")
            .execute()
            .path("user.name").entity(String.class).isEqualTo("John");
    }
}
```

### Integration Testing

```bash
# Using GraphiQL browser interface
http://localhost:8080/graphiql

# Using curl
curl -X POST http://localhost:8080/graphql \
  -H "Content-Type: application/json" \
  -d '{"query": "{ users { id name } }"}'
```

## Common Issues & Solutions

### Issue: Schema not found
**Solution:** Ensure `schema.graphqls` is in `src/main/resources/graphql/`

### Issue: GraphiQL not accessible
**Solution:** Check `spring.graphql.graphiql.enabled=true` in application.properties

### Issue: Fields returning null
**Solution:** Verify field names in schema match Java class field names exactly

### Issue: Input types not working
**Solution:** Ensure input classes have proper getters/setters and default constructor

## Advanced GraphQL Features

### 1. Pagination
```graphql
type Query {
  users(page: Int!, size: Int!): UserPage!
}

type UserPage {
  users: [User!]!
  totalPages: Int!
  totalElements: Int!
}
```

### 2. Filtering
```graphql
type Query {
  users(filter: UserFilter): [User!]!
}

input UserFilter {
  name: String
  minAge: Int
  maxAge: Int
}
```

### 3. Subscriptions (Real-time)
```graphql
type Subscription {
  userCreated: User!
  userUpdated(id: ID!): User!
}
```

### 4. Custom Scalars
```graphql
scalar DateTime
scalar Email

type User {
  id: ID!
  email: Email!
  createdAt: DateTime!
}
```

## Migration Checklist

- [ ] Add GraphQL dependencies to pom.xml
- [ ] Create GraphQL schema file
- [ ] Create input DTOs
- [ ] Create GraphQL controller
- [ ] Configure GraphQL in application.properties
- [ ] Test with GraphiQL
- [ ] Write unit tests for GraphQL controller
- [ ] Update API documentation
- [ ] (Optional) Remove REST controller if not needed

## Conclusion

Our clean architecture makes it trivial to add GraphQL:
1. Add dependencies
2. Define schema
3. Create GraphQL controller
4. **No changes to business logic needed!**

This demonstrates the power of proper separation of concerns - you can support multiple API styles (REST, GraphQL, gRPC, etc.) without duplicating business logic.
