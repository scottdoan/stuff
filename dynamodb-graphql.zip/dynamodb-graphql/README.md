# Spring Boot DynamoDB API - REST & GraphQL

A Spring Boot API with **clean architecture** supporting both REST and GraphQL, demonstrating how proper separation of concerns allows multiple API styles without code duplication.

## Key Features

✅ **Clean Architecture** - Separated domain models and database entities  
✅ **Dual API Support** - Both REST and GraphQL using the same business logic  
✅ **Database Independence** - Easy to switch from DynamoDB to MySQL/PostgreSQL/MongoDB  
✅ **Comprehensive JavaDocs** - All classes and methods fully documented  
✅ **Complete Test Suite** - 38 unit tests covering REST, GraphQL, and all layers  
✅ **Java 21** - Built with the latest LTS version  
✅ **GraphiQL Interface** - Interactive GraphQL playground included  
✅ **Production Ready** - Follows industry best practices and SOLID principles  

## Why This Architecture?

**Problem with tight coupling:**
- Domain models mixed with database annotations (JPA, DynamoDB, etc.)
- Hard to switch databases without rewriting business logic
- Testing requires database setup

**Benefits of this approach:**
- ✅ **Database Independence**: Switch from DynamoDB to MySQL/PostgreSQL without changing business logic
- ✅ **Testability**: Mock repositories easily without database
- ✅ **Clean Separation**: Business logic doesn't know about persistence
- ✅ **Maintainability**: Changes to database don't affect controllers/services

## Architecture Layers

```
┌─────────────────────────────────────────────┐
│          Controller Layer                   │  (REST API - domain models)
│          /api/users endpoints                │
└─────────────────┬───────────────────────────┘
                  │
┌─────────────────▼───────────────────────────┐
│          Service Layer                       │  (Business Logic - domain models)
│          UserService                         │
└─────────────────┬───────────────────────────┘
                  │
┌─────────────────▼───────────────────────────┐
│     Repository Interface (Contract)          │  (Abstraction)
│          UserRepository                      │
└─────────────────┬───────────────────────────┘
                  │
      ┌───────────┴──────────┐
      │                      │
┌─────▼─────────┐   ┌───────▼──────────┐
│   DynamoDB    │   │   MySQL/JPA      │  (Implementations)
│ Implementation│   │ Implementation   │
└───────────────┘   └──────────────────┘
```

## Project Structure

```
src/main/java/com/example/dynamodbapi/
├── model/                      # Domain Models (database-agnostic)
│   └── User.java              # Pure POJO, no database annotations
├── entity/                     # Database Entities (database-specific)
│   └── UserEntity.java        # DynamoDB-specific with @DynamoDbBean
├── mapper/                     # Converts between Model and Entity
│   └── UserMapper.java        # Model ↔ Entity conversion
├── repository/                 # Data Access Layer
│   ├── UserRepository.java           # Interface (contract)
│   ├── DynamoDbUserRepository.java   # DynamoDB implementation
│   └── JpaUserRepository.java        # MySQL/PostgreSQL example
├── service/                    # Business Logic
│   └── UserService.java       # Works with domain models only
├── controller/                 # REST API
│   └── UserController.java    # Works with domain models only
└── config/
    └── DynamoDBConfig.java    # DynamoDB configuration
```

## Key Components Explained

### 1. Domain Model (`model/User.java`)
```java
// Pure Java object - no database annotations
public class User {
    private String id;
    private String name;
    private String email;
    private Integer age;
    // getters and setters
}
```

### 2. Database Entity (`entity/UserEntity.java`)
```java
// DynamoDB-specific - has all the database annotations
@DynamoDbBean
public class UserEntity {
    @DynamoDbPartitionKey
    private String userId;
    private String name;
    // ...
}
```

### 3. Mapper (`mapper/UserMapper.java`)
```java
// Converts between domain model and database entity
public class UserMapper {
    public UserEntity toEntity(User user) { ... }
    public User toModel(UserEntity entity) { ... }
}
```

### 4. Repository Interface (`repository/UserRepository.java`)
```java
// Contract - no implementation details
public interface UserRepository {
    User save(User user);
    Optional<User> findById(String id);
    List<User> findAll();
    // ...
}
```

### 5. DynamoDB Implementation (`repository/DynamoDbUserRepository.java`)
```java
@Repository
public class DynamoDbUserRepository implements UserRepository {
    // DynamoDB-specific code here
    // Uses UserMapper to convert between User and UserEntity
}
```

## How to Switch Databases

### From DynamoDB to MySQL/PostgreSQL

**Step 1:** Add JPA dependencies to `pom.xml`
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
</dependency>
```

**Step 2:** Create JPA Entity
```java
@Entity
@Table(name = "users")
public class UserJpaEntity {
    @Id
    private String id;
    private String name;
    private String email;
    private Integer age;
    // getters and setters
}
```

**Step 3:** Create JPA Repository Implementation
```java
@Repository
@Primary  // Makes this the default implementation
public class JpaUserRepository implements UserRepository {
    
    private final UserJpaEntityRepository jpaRepo; // Spring Data JPA
    private final UserJpaMapper mapper;
    
    @Override
    public User save(User user) {
        UserJpaEntity entity = mapper.toJpaEntity(user);
        UserJpaEntity saved = jpaRepo.save(entity);
        return mapper.toModel(saved);
    }
    // ... implement other methods
}
```

**Step 4:** Update `application.properties`
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/mydb
spring.datasource.username=root
spring.datasource.password=password
spring.jpa.hibernate.ddl-auto=update
```

**That's it!** No changes needed to:
- ❌ Controller
- ❌ Service
- ❌ Domain Model
- ❌ Tests (if you used mock repositories)

## Running the Application

### Prerequisites
- Java 21+
- Maven 3.6+
- AWS DynamoDB (or DynamoDB Local)

### Setup

1. **Create DynamoDB Table:**
```bash
aws dynamodb create-table \
    --table-name Users \
    --attribute-definitions AttributeName=userId,AttributeType=S \
    --key-schema AttributeName=userId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region us-east-1
```

2. **Configure AWS Credentials:**
```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-east-1
```

3. **Run the Application:**
```bash
mvn spring-boot:run
```

## API Endpoints

All endpoints remain the same regardless of database:

```bash
# Create User
POST http://localhost:8080/api/users
{
    "name": "John Doe",
    "email": "john@example.com",
    "age": 30
}

# Get All Users
GET http://localhost:8080/api/users

# Get User by ID
GET http://localhost:8080/api/users/{id}

# Update User
PUT http://localhost:8080/api/users/{id}
{
    "name": "John Updated",
    "email": "john.updated@example.com",
    "age": 31
}

# Delete User
DELETE http://localhost:8080/api/users/{id}
```

## GraphQL Endpoints

**GraphQL Endpoint**: `POST http://localhost:8080/graphql`  
**GraphiQL Interface**: `http://localhost:8080/graphiql` (Interactive playground)

### Example Queries

#### Get All Users
```graphql
query {
  users {
    id
    name
    email
    age
  }
}
```

#### Get User by ID
```graphql
query {
  user(id: "123") {
    id
    name
    email
  }
}
```

#### Search Users by Name
```graphql
query {
  searchUsers(name: "john") {
    id
    name
    email
  }
}
```

### Example Mutations

#### Create User
```graphql
mutation {
  createUser(input: {
    name: "John Doe"
    email: "john@example.com"
    age: 30
  }) {
    id
    name
    email
  }
}
```

#### Update User
```graphql
mutation {
  updateUser(id: "123", input: {
    name: "John Updated"
    email: "john.updated@example.com"
  }) {
    id
    name
    email
  }
}
```

#### Delete User
```graphql
mutation {
  deleteUser(id: "123")
}
```

### GraphQL Advantages

✅ **Request only needed fields** - Reduces data transfer  
✅ **Single request for multiple resources** - No over-fetching  
✅ **Strongly typed schema** - Self-documenting API  
✅ **Interactive playground** - GraphiQL for testing  

See [GRAPHQL_MIGRATION_GUIDE.md](GRAPHQL_MIGRATION_GUIDE.md) for complete GraphQL documentation.

## Testing

The decoupled architecture makes testing much easier - no database required!

### Test Suite

**38 comprehensive unit tests** covering:
- ✅ Mapper layer (6 tests) - Domain model ↔ Entity conversion
- ✅ Service layer (12 tests) - Business logic with mocked repositories
- ✅ REST Controller layer (10 tests) - REST API endpoints with MockMvc
- ✅ GraphQL Controller layer (10 tests) - GraphQL queries and mutations

### Run Tests

```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=UserServiceTest

# Run with coverage report
mvn test jacoco:report
```

### Test Example

Tests use Mockito for mocking, so no database is needed:

```java
@Test
@DisplayName("Should create user with generated ID when ID is null")
void testCreateUser_GeneratesId() {
    // Given - Mock the repository (no database needed!)
    User userWithoutId = new User(null, "Jane", "jane@example.com", 25);
    when(userRepository.save(any())).thenAnswer(i -> i.getArgument(0));
    
    // When - Execute the service method
    User createdUser = userService.createUser(userWithoutId);
    
    // Then - Verify the results
    assertThat(createdUser.getId()).isNotNull();
    verify(userRepository, times(1)).save(any());
}
```

See [TESTING_GUIDE.md](TESTING_GUIDE.md) for comprehensive testing documentation.

### Benefits of Our Test Suite

- **Fast**: All tests run in seconds (no database startup)
- **Isolated**: Each test is independent
- **Maintainable**: Clear structure and descriptive names
- **Comprehensive**: Success and failure cases covered

## JavaDoc Documentation

All classes and methods are comprehensively documented with JavaDoc comments.

### Generate JavaDoc HTML

```bash
mvn javadoc:javadoc
```

View generated documentation at: `target/site/apidocs/index.html`

### JavaDoc Example

```java
/**
 * Service layer for User business logic operations.
 * <p>
 * This service provides business logic for managing users, including
 * CRUD operations and ID generation. It acts as an intermediary between
 * the controller layer and the repository layer.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@Service
public class UserService {
    /**
     * Creates a new user in the system.
     * <p>
     * If the user does not have an ID, a UUID will be automatically
     * generated before saving.
     * </p>
     *
     * @param user the user to create; must not be null
     * @return the created user with ID populated
     * @throws IllegalArgumentException if user is null
     */
    public User createUser(User user) { ... }
}
```

## Design Patterns Used

1. **Repository Pattern**: Abstracts data access logic
2. **Dependency Injection**: Constructor injection for loose coupling
3. **Data Mapper Pattern**: Converts between layers (UserMapper)
4. **Interface Segregation**: Repository interface separates contract from implementation
5. **Dependency Inversion**: High-level modules depend on abstractions, not implementations

## Adding New Attributes

To add a new field (e.g., `phoneNumber`):

1. **Update Domain Model** (`User.java`)
```java
private String phoneNumber;
// add getter and setter
```

2. **Update Database Entity** (`UserEntity.java`)
```java
private String phoneNumber;
@DynamoDbAttribute("phoneNumber")
public String getPhoneNumber() { return phoneNumber; }
```

3. **Update Mapper** (`UserMapper.java`)
```java
entity.setPhoneNumber(user.getPhoneNumber());
user.setPhoneNumber(entity.getPhoneNumber());
```

That's it! No changes to controller, service, or repository interface.

## Technologies Used

- **Spring Boot 3.2.0** - Application framework
- **AWS SDK for Java 2.x** - DynamoDB integration
- **Repository Pattern** - Data access abstraction
- **Mapper Pattern** - Layer conversion

## Best Practices Implemented

✅ Separation of Concerns (SoC)
✅ Single Responsibility Principle (SRP)
✅ Dependency Inversion Principle (DIP)
✅ Interface Segregation Principle (ISP)
✅ Don't Repeat Yourself (DRY)
✅ Clean Architecture layers

## Future Enhancements

- Add DTO (Data Transfer Object) layer for API requests/responses
- Implement caching layer
- Add pagination for `findAll()`
- Add custom query methods in repository
- Implement Spring Profiles for different databases
- Add comprehensive unit and integration tests
