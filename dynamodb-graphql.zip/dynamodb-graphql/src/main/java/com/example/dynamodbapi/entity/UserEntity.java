package com.example.dynamodbapi.entity;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;

/**
 * DynamoDB entity representing a User record in the database.
 * <p>
 * This class is specific to DynamoDB implementation and contains all
 * DynamoDB-specific annotations and field mappings. It is part of the
 * infrastructure layer and is isolated from the domain model.
 * </p>
 * <p>
 * This entity is mapped to/from the domain model {@link com.example.dynamodbapi.model.User}
 * using {@link com.example.dynamodbapi.mapper.UserMapper}.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 * @see com.example.dynamodbapi.model.User
 * @see com.example.dynamodbapi.mapper.UserMapper
 */
@DynamoDbBean
public class UserEntity {
    
    /**
     * Unique identifier for the user in DynamoDB.
     * This serves as the partition key for the DynamoDB table.
     */
    private String userId;
    
    /**
     * Full name of the user.
     */
    private String name;
    
    /**
     * Email address of the user.
     */
    private String email;
    
    /**
     * Age of the user in years.
     */
    private Integer age;

    /**
     * Default constructor required by DynamoDB Enhanced Client.
     */
    public UserEntity() {
    }

    /**
     * Constructs a new UserEntity with the specified details.
     *
     * @param userId the unique identifier for the user (partition key)
     * @param name   the full name of the user
     * @param email  the email address of the user
     * @param age    the age of the user in years
     */
    public UserEntity(String userId, String name, String email, Integer age) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.age = age;
    }

    /**
     * Gets the user ID which serves as the DynamoDB partition key.
     *
     * @return the user's unique identifier
     */
    @DynamoDbPartitionKey
    @DynamoDbAttribute("userId")
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user ID (partition key).
     *
     * @param userId the unique identifier to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the name of the user.
     *
     * @return the user's name
     */
    @DynamoDbAttribute("name")
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the user.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the email address of the user.
     *
     * @return the user's email address
     */
    @DynamoDbAttribute("email")
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the age of the user.
     *
     * @return the user's age in years
     */
    @DynamoDbAttribute("age")
    public Integer getAge() {
        return age;
    }

    /**
     * Sets the age of the user.
     *
     * @param age the age to set in years
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * Returns a string representation of the UserEntity.
     *
     * @return a string containing all entity properties
     */
    @Override
    public String toString() {
        return "UserEntity{" +
                "userId='" + userId + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", age=" + age +
                '}';
    }
}
