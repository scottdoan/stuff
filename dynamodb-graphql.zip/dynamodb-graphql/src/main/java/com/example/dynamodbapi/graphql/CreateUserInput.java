package com.example.dynamodbapi.graphql;

/**
 * Input DTO for creating a new user via GraphQL.
 * <p>
 * This class represents the input arguments for the createUser mutation.
 * It is separate from the domain model to provide a clean API contract.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
public class CreateUserInput {
    
    private String name;
    private String email;
    private Integer age;

    /**
     * Default constructor for framework use.
     */
    public CreateUserInput() {
    }

    /**
     * Constructs a new CreateUserInput with the specified details.
     *
     * @param name  the user's name
     * @param email the user's email
     * @param age   the user's age
     */
    public CreateUserInput(String name, String email, Integer age) {
        this.name = name;
        this.email = email;
        this.age = age;
    }

    /**
     * Gets the user's name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the user's name.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the user's email.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email.
     *
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the user's age.
     *
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * Sets the user's age.
     *
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }
}
