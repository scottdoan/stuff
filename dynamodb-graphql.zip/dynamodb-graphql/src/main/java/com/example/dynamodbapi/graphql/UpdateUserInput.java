package com.example.dynamodbapi.graphql;

/**
 * Input DTO for updating an existing user via GraphQL.
 * <p>
 * This class represents the input arguments for the updateUser mutation.
 * All fields are optional to support partial updates.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
public class UpdateUserInput {
    
    private String name;
    private String email;
    private Integer age;

    /**
     * Default constructor for framework use.
     */
    public UpdateUserInput() {
    }

    /**
     * Constructs a new UpdateUserInput with the specified details.
     *
     * @param name  the user's name (optional)
     * @param email the user's email (optional)
     * @param age   the user's age (optional)
     */
    public UpdateUserInput(String name, String email, Integer age) {
        this.name = name;
        this.email = email;
        this.age = age;
    }

    /**
     * Gets the user's name.
     *
     * @return the name, or null if not being updated
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the user's name.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the user's email.
     *
     * @return the email, or null if not being updated
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email.
     *
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the user's age.
     *
     * @return the age, or null if not being updated
     */
    public Integer getAge() {
        return age;
    }

    /**
     * Sets the user's age.
     *
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }
}
