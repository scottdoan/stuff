package com.example.dynamodbapi.controller;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for User resource operations.
 * <p>
 * This controller provides RESTful endpoints for managing users through
 * standard HTTP methods. It follows REST conventions for resource manipulation
 * and returns appropriate HTTP status codes.
 * </p>
 * <p>
 * All endpoints work with domain models ({@link User}) and are independent
 * of the underlying database technology.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    /**
     * Constructs a new UserController with the specified service.
     *
     * @param userService the service layer for user operations; must not be null
     */
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Creates a new user.
     * <p>
     * If the user does not have an ID in the request body, one will be
     * automatically generated.
     * </p>
     *
     * @param user the user to create; must not be null
     * @return ResponseEntity containing the created user and HTTP 201 (Created) status
     */
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.createUser(user);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    /**
     * Retrieves a user by their unique identifier.
     *
     * @param id the unique identifier of the user; must not be null
     * @return ResponseEntity containing the user and HTTP 200 (OK) if found,
     *         or HTTP 404 (Not Found) if the user does not exist
     */
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable String id) {
        return userService.getUserById(id)
                .map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Retrieves all users in the system.
     *
     * @return ResponseEntity containing a list of all users and HTTP 200 (OK) status.
     *         The list may be empty but is never null.
     */
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    /**
     * Updates an existing user's information.
     * <p>
     * All fields in the request body will update the corresponding user.
     * The user ID in the path must match an existing user.
     * </p>
     *
     * @param id   the unique identifier of the user to update; must not be null
     * @param user the user object containing updated information; must not be null
     * @return ResponseEntity containing the updated user and HTTP 200 (OK) if found,
     *         or HTTP 404 (Not Found) if the user does not exist
     */
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable String id, @RequestBody User user) {
        return userService.updateUser(id, user)
                .map(updatedUser -> new ResponseEntity<>(updatedUser, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Deletes a user by their unique identifier.
     *
     * @param id the unique identifier of the user to delete; must not be null
     * @return ResponseEntity with HTTP 204 (No Content) if the user was deleted,
     *         or HTTP 404 (Not Found) if the user does not exist
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable String id) {
        boolean deleted = userService.deleteUser(id);
        return deleted ? 
                new ResponseEntity<>(HttpStatus.NO_CONTENT) : 
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
