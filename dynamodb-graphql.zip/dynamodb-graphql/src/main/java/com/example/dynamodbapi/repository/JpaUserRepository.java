package com.example.dynamodbapi.repository;

import com.example.dynamodbapi.model.User;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * EXAMPLE: MySQL/PostgreSQL implementation using JPA
 * 
 * To switch from DynamoDB to MySQL:
 * 1. Add this implementation
 * 2. Add JPA dependencies to pom.xml
 * 3. Create @Entity version of User for JPA
 * 4. Activate the "mysql" profile (or use @Primary annotation)
 * 
 * No changes needed to Service or Controller layers!
 */
@Repository
@Profile("mysql")  // Only active when 'mysql' profile is set
public class JpaUserRepository implements UserRepository {

    // private final JpaUserEntityRepository jpaRepository; // Spring Data JPA interface

    @Override
    public User save(User user) {
        // Convert to JPA entity, save, convert back
        throw new UnsupportedOperationException("MySQL implementation not yet configured");
    }

    @Override
    public Optional<User> findById(String id) {
        throw new UnsupportedOperationException("MySQL implementation not yet configured");
    }

    @Override
    public List<User> findAll() {
        throw new UnsupportedOperationException("MySQL implementation not yet configured");
    }

    @Override
    public void deleteById(String id) {
        throw new UnsupportedOperationException("MySQL implementation not yet configured");
    }

    @Override
    public User update(User user) {
        throw new UnsupportedOperationException("MySQL implementation not yet configured");
    }
}
