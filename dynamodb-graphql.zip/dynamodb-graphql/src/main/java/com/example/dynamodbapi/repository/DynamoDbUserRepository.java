package com.example.dynamodbapi.repository;

import com.example.dynamodbapi.entity.UserEntity;
import com.example.dynamodbapi.mapper.UserMapper;
import com.example.dynamodbapi.model.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * DynamoDB-specific implementation of the {@link UserRepository} interface.
 * <p>
 * This repository provides data access operations for users stored in AWS DynamoDB.
 * It uses the AWS SDK Enhanced Client for simplified DynamoDB operations and
 * {@link UserMapper} to convert between domain models and database entities.
 * </p>
 * <p>
 * To switch to a different database (MySQL, PostgreSQL, MongoDB, etc.),
 * simply create a new implementation of {@link UserRepository} and mark it
 * as {@code @Primary} or use Spring profiles. No changes are required in
 * the service or controller layers.
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 * @see UserRepository
 * @see UserEntity
 * @see UserMapper
 */
@Repository
public class DynamoDbUserRepository implements UserRepository {

    private final DynamoDbTable<UserEntity> userTable;
    private final UserMapper userMapper;

    /**
     * Constructs a new DynamoDbUserRepository.
     *
     * @param dynamoDbEnhancedClient the DynamoDB Enhanced Client; must not be null
     * @param tableName             the name of the DynamoDB table; must not be null or empty
     * @param userMapper            the mapper for converting between models and entities; must not be null
     */
    public DynamoDbUserRepository(DynamoDbEnhancedClient dynamoDbEnhancedClient,
                                  @Value("${aws.dynamodb.table-name}") String tableName,
                                  UserMapper userMapper) {
        this.userTable = dynamoDbEnhancedClient.table(tableName, TableSchema.fromBean(UserEntity.class));
        this.userMapper = userMapper;
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses DynamoDB's {@code putItem} operation which creates a new item
     * or replaces an existing item with the same partition key.
     * </p>
     */
    @Override
    public User save(User user) {
        UserEntity entity = userMapper.toEntity(user);
        userTable.putItem(entity);
        return userMapper.toModel(entity);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses DynamoDB's {@code getItem} operation to retrieve a single item
     * by its partition key.
     * </p>
     */
    @Override
    public Optional<User> findById(String id) {
        Key key = Key.builder()
                .partitionValue(id)
                .build();
        UserEntity entity = userTable.getItem(key);
        return Optional.ofNullable(userMapper.toModel(entity));
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses DynamoDB's {@code scan} operation to retrieve all items from the table.
     * <strong>Warning:</strong> Scan operations can be expensive for large tables.
     * Consider implementing pagination for production use.
     * </p>
     */
    @Override
    public List<User> findAll() {
        List<UserEntity> entities = new ArrayList<>();
        userTable.scan(ScanEnhancedRequest.builder().build())
                .items()
                .forEach(entities::add);
        
        return entities.stream()
                .map(userMapper::toModel)
                .collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses DynamoDB's {@code deleteItem} operation to remove an item
     * by its partition key. If the item doesn't exist, the operation
     * completes successfully without error.
     * </p>
     */
    @Override
    public void deleteById(String id) {
        Key key = Key.builder()
                .partitionValue(id)
                .build();
        userTable.deleteItem(key);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses DynamoDB's {@code updateItem} operation to update an existing item.
     * All attributes will be updated with the values from the provided user.
     * </p>
     */
    @Override
    public User update(User user) {
        UserEntity entity = userMapper.toEntity(user);
        UserEntity updated = userTable.updateItem(entity);
        return userMapper.toModel(updated);
    }
}
