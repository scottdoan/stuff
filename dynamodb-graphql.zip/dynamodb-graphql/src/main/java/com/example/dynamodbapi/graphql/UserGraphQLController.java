package com.example.dynamodbapi.graphql;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.service.UserService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.stream.Collectors;

/**
 * GraphQL controller (resolver) for User operations.
 * <p>
 * This controller handles GraphQL queries and mutations for user management.
 * It uses the same {@link UserService} as the REST controller, demonstrating
 * how our clean architecture allows multiple API styles (REST and GraphQL)
 * to coexist without duplicating business logic.
 * </p>
 * <p>
 * GraphQL endpoints are available at: /graphql
 * GraphiQL interface (dev tool) at: /graphiql
 * </p>
 *
 * @author Spring Boot DynamoDB API
 * @version 1.0
 * @since 1.0
 */
@Controller
public class UserGraphQLController {

    private final UserService userService;

    /**
     * Constructs a new UserGraphQLController.
     *
     * @param userService the service layer for user operations; must not be null
     */
    public UserGraphQLController(UserService userService) {
        this.userService = userService;
    }

    /**
     * GraphQL Query: Retrieves a user by their unique identifier.
     * <p>
     * GraphQL query example:
     * <pre>
     * query {
     *   user(id: "123") {
     *     id
     *     name
     *     email
     *     age
     *   }
     * }
     * </pre>
     * </p>
     *
     * @param id the unique identifier of the user
     * @return the user if found, null otherwise
     */
    @QueryMapping
    public User user(@Argument String id) {
        return userService.getUserById(id).orElse(null);
    }

    /**
     * GraphQL Query: Retrieves all users in the system.
     * <p>
     * GraphQL query example:
     * <pre>
     * query {
     *   users {
     *     id
     *     name
     *     email
     *   }
     * }
     * </pre>
     * </p>
     *
     * @return a list of all users; never null but may be empty
     */
    @QueryMapping
    public List<User> users() {
        return userService.getAllUsers();
    }

    /**
     * GraphQL Query: Searches for users by name (case-insensitive).
     * <p>
     * GraphQL query example:
     * <pre>
     * query {
     *   searchUsers(name: "john") {
     *     id
     *     name
     *     email
     *   }
     * }
     * </pre>
     * </p>
     *
     * @param name the name or partial name to search for
     * @return a list of matching users; never null but may be empty
     */
    @QueryMapping
    public List<User> searchUsers(@Argument String name) {
        return userService.getAllUsers().stream()
                .filter(user -> user.getName() != null && 
                               user.getName().toLowerCase().contains(name.toLowerCase()))
                .collect(Collectors.toList());
    }

    /**
     * GraphQL Mutation: Creates a new user.
     * <p>
     * GraphQL mutation example:
     * <pre>
     * mutation {
     *   createUser(input: {
     *     name: "John Doe"
     *     email: "john@example.com"
     *     age: 30
     *   }) {
     *     id
     *     name
     *     email
     *     age
     *   }
     * }
     * </pre>
     * </p>
     *
     * @param input the user creation input containing name, email, and age
     * @return the created user with generated ID
     */
    @MutationMapping
    public User createUser(@Argument CreateUserInput input) {
        User user = new User();
        user.setName(input.getName());
        user.setEmail(input.getEmail());
        user.setAge(input.getAge());
        return userService.createUser(user);
    }

    /**
     * GraphQL Mutation: Updates an existing user.
     * <p>
     * GraphQL mutation example:
     * <pre>
     * mutation {
     *   updateUser(id: "123", input: {
     *     name: "John Updated"
     *     email: "john.updated@example.com"
     *   }) {
     *     id
     *     name
     *     email
     *   }
     * }
     * </pre>
     * </p>
     *
     * @param id    the unique identifier of the user to update
     * @param input the update input containing fields to modify
     * @return the updated user if found, null otherwise
     */
    @MutationMapping
    public User updateUser(@Argument String id, @Argument UpdateUserInput input) {
        User updateData = new User();
        updateData.setName(input.getName());
        updateData.setEmail(input.getEmail());
        updateData.setAge(input.getAge());
        return userService.updateUser(id, updateData).orElse(null);
    }

    /**
     * GraphQL Mutation: Deletes a user by their unique identifier.
     * <p>
     * GraphQL mutation example:
     * <pre>
     * mutation {
     *   deleteUser(id: "123")
     * }
     * </pre>
     * </p>
     *
     * @param id the unique identifier of the user to delete
     * @return true if the user was deleted, false if not found
     */
    @MutationMapping
    public Boolean deleteUser(@Argument String id) {
        return userService.deleteUser(id);
    }
}
