package com.example.dynamodbapi.graphql;

import com.example.dynamodbapi.model.User;
import com.example.dynamodbapi.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.graphql.GraphQlTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.graphql.test.tester.GraphQlTester;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link UserGraphQLController}.
 * <p>
 * These tests verify GraphQL queries and mutations using Spring's GraphQlTester,
 * demonstrating how GraphQL endpoints can be tested without starting a server.
 * </p>
 */
@GraphQlTest(UserGraphQLController.class)
@DisplayName("UserGraphQLController Tests")
class UserGraphQLControllerTest {

    @Autowired
    private GraphQlTester graphQlTester;

    @MockBean
    private UserService userService;

    @Test
    @DisplayName("Query: user - Should return user by ID")
    void testGetUserById() {
        // Given
        User user = new User("123", "John Doe", "john@example.com", 30);
        when(userService.getUserById("123")).thenReturn(Optional.of(user));

        // When & Then
        graphQlTester
                .document("""
                    query($id: ID!) {
                        user(id: $id) {
                            id
                            name
                            email
                            age
                        }
                    }
                """)
                .variable("id", "123")
                .execute()
                .path("user.id").entity(String.class).isEqualTo("123")
                .path("user.name").entity(String.class).isEqualTo("John Doe")
                .path("user.email").entity(String.class).isEqualTo("john@example.com")
                .path("user.age").entity(Integer.class).isEqualTo(30);
    }

    @Test
    @DisplayName("Query: user - Should return null when user not found")
    void testGetUserById_NotFound() {
        // Given
        when(userService.getUserById("999")).thenReturn(Optional.empty());

        // When & Then
        graphQlTester
                .document("""
                    query($id: ID!) {
                        user(id: $id) {
                            id
                            name
                        }
                    }
                """)
                .variable("id", "999")
                .execute()
                .path("user").valueIsNull();
    }

    @Test
    @DisplayName("Query: users - Should return all users")
    void testGetAllUsers() {
        // Given
        User user1 = new User("123", "John Doe", "john@example.com", 30);
        User user2 = new User("456", "Jane Smith", "jane@example.com", 25);
        List<User> users = Arrays.asList(user1, user2);
        when(userService.getAllUsers()).thenReturn(users);

        // When & Then
        graphQlTester
                .document("""
                    query {
                        users {
                            id
                            name
                            email
                        }
                    }
                """)
                .execute()
                .path("users").entityList(User.class).hasSize(2)
                .path("users[0].id").entity(String.class).isEqualTo("123")
                .path("users[0].name").entity(String.class).isEqualTo("John Doe")
                .path("users[1].id").entity(String.class).isEqualTo("456")
                .path("users[1].name").entity(String.class).isEqualTo("Jane Smith");
    }

    @Test
    @DisplayName("Query: users - Should return empty list when no users exist")
    void testGetAllUsers_Empty() {
        // Given
        when(userService.getAllUsers()).thenReturn(List.of());

        // When & Then
        graphQlTester
                .document("""
                    query {
                        users {
                            id
                            name
                        }
                    }
                """)
                .execute()
                .path("users").entityList(User.class).hasSize(0);
    }

    @Test
    @DisplayName("Query: searchUsers - Should filter users by name")
    void testSearchUsers() {
        // Given
        User user1 = new User("123", "John Doe", "john@example.com", 30);
        User user2 = new User("456", "Jane Smith", "jane@example.com", 25);
        User user3 = new User("789", "Johnny Cash", "johnny@example.com", 40);
        List<User> allUsers = Arrays.asList(user1, user2, user3);
        when(userService.getAllUsers()).thenReturn(allUsers);

        // When & Then
        graphQlTester
                .document("""
                    query($name: String!) {
                        searchUsers(name: $name) {
                            id
                            name
                        }
                    }
                """)
                .variable("name", "john")
                .execute()
                .path("searchUsers").entityList(User.class).hasSize(2)
                .path("searchUsers[0].name").entity(String.class).isEqualTo("John Doe")
                .path("searchUsers[1].name").entity(String.class).isEqualTo("Johnny Cash");
    }

    @Test
    @DisplayName("Mutation: createUser - Should create user successfully")
    void testCreateUser() {
        // Given
        User createdUser = new User("123", "John Doe", "john@example.com", 30);
        when(userService.createUser(any(User.class))).thenReturn(createdUser);

        // When & Then
        graphQlTester
                .document("""
                    mutation($input: CreateUserInput!) {
                        createUser(input: $input) {
                            id
                            name
                            email
                            age
                        }
                    }
                """)
                .variable("input", """
                    {
                        "name": "John Doe",
                        "email": "john@example.com",
                        "age": 30
                    }
                """)
                .execute()
                .path("createUser.id").entity(String.class).isEqualTo("123")
                .path("createUser.name").entity(String.class).isEqualTo("John Doe")
                .path("createUser.email").entity(String.class).isEqualTo("john@example.com")
                .path("createUser.age").entity(Integer.class).isEqualTo(30);
    }

    @Test
    @DisplayName("Mutation: updateUser - Should update user successfully")
    void testUpdateUser() {
        // Given
        User updatedUser = new User("123", "John Updated", "john.updated@example.com", 31);
        when(userService.updateUser(eq("123"), any(User.class))).thenReturn(Optional.of(updatedUser));

        // When & Then
        graphQlTester
                .document("""
                    mutation($id: ID!, $input: UpdateUserInput!) {
                        updateUser(id: $id, input: $input) {
                            id
                            name
                            email
                            age
                        }
                    }
                """)
                .variable("id", "123")
                .variable("input", """
                    {
                        "name": "John Updated",
                        "email": "john.updated@example.com",
                        "age": 31
                    }
                """)
                .execute()
                .path("updateUser.id").entity(String.class).isEqualTo("123")
                .path("updateUser.name").entity(String.class).isEqualTo("John Updated")
                .path("updateUser.email").entity(String.class).isEqualTo("john.updated@example.com");
    }

    @Test
    @DisplayName("Mutation: updateUser - Should return null when user not found")
    void testUpdateUser_NotFound() {
        // Given
        when(userService.updateUser(eq("999"), any(User.class))).thenReturn(Optional.empty());

        // When & Then
        graphQlTester
                .document("""
                    mutation($id: ID!, $input: UpdateUserInput!) {
                        updateUser(id: $id, input: $input) {
                            id
                            name
                        }
                    }
                """)
                .variable("id", "999")
                .variable("input", """
                    {
                        "name": "John Updated"
                    }
                """)
                .execute()
                .path("updateUser").valueIsNull();
    }

    @Test
    @DisplayName("Mutation: deleteUser - Should delete user successfully")
    void testDeleteUser() {
        // Given
        when(userService.deleteUser("123")).thenReturn(true);

        // When & Then
        graphQlTester
                .document("""
                    mutation($id: ID!) {
                        deleteUser(id: $id)
                    }
                """)
                .variable("id", "123")
                .execute()
                .path("deleteUser").entity(Boolean.class).isEqualTo(true);
    }

    @Test
    @DisplayName("Mutation: deleteUser - Should return false when user not found")
    void testDeleteUser_NotFound() {
        // Given
        when(userService.deleteUser("999")).thenReturn(false);

        // When & Then
        graphQlTester
                .document("""
                    mutation($id: ID!) {
                        deleteUser(id: $id)
                    }
                """)
                .variable("id", "999")
                .execute()
                .path("deleteUser").entity(Boolean.class).isEqualTo(false);
    }

    @Test
    @DisplayName("Query: Selective fields - Should return only requested fields")
    void testSelectiveFields() {
        // Given
        User user = new User("123", "John Doe", "john@example.com", 30);
        when(userService.getUserById("123")).thenReturn(Optional.of(user));

        // When & Then - Only request name and email
        graphQlTester
                .document("""
                    query($id: ID!) {
                        user(id: $id) {
                            name
                            email
                        }
                    }
                """)
                .variable("id", "123")
                .execute()
                .path("user.name").entity(String.class).isEqualTo("John Doe")
                .path("user.email").entity(String.class).isEqualTo("john@example.com")
                // Age was not requested, so it shouldn't be validated
                .path("user.id").pathDoesNotExist();
    }
}
