package com.example.dynamodbapi.mapper;

import com.example.dynamodbapi.entity.UserEntity;
import com.example.dynamodbapi.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link UserMapper}.
 * <p>
 * These tests verify the correct mapping between domain models and entities
 * in both directions, including null handling.
 * </p>
 */
@DisplayName("UserMapper Tests")
class UserMapperTest {

    private UserMapper userMapper;

    @BeforeEach
    void setUp() {
        userMapper = new UserMapper();
    }

    @Test
    @DisplayName("Should convert User domain model to UserEntity")
    void testToEntity_Success() {
        // Given
        User user = new User("123", "John Doe", "john@example.com", 30);

        // When
        UserEntity entity = userMapper.toEntity(user);

        // Then
        assertThat(entity).isNotNull();
        assertThat(entity.getUserId()).isEqualTo("123");
        assertThat(entity.getName()).isEqualTo("John Doe");
        assertThat(entity.getEmail()).isEqualTo("john@example.com");
        assertThat(entity.getAge()).isEqualTo(30);
    }

    @Test
    @DisplayName("Should return null when converting null User to entity")
    void testToEntity_NullInput() {
        // When
        UserEntity entity = userMapper.toEntity(null);

        // Then
        assertThat(entity).isNull();
    }

    @Test
    @DisplayName("Should convert UserEntity to User domain model")
    void testToModel_Success() {
        // Given
        UserEntity entity = new UserEntity("456", "Jane Smith", "jane@example.com", 25);

        // When
        User user = userMapper.toModel(entity);

        // Then
        assertThat(user).isNotNull();
        assertThat(user.getId()).isEqualTo("456");
        assertThat(user.getName()).isEqualTo("Jane Smith");
        assertThat(user.getEmail()).isEqualTo("jane@example.com");
        assertThat(user.getAge()).isEqualTo(25);
    }

    @Test
    @DisplayName("Should return null when converting null UserEntity to model")
    void testToModel_NullInput() {
        // When
        User user = userMapper.toModel(null);

        // Then
        assertThat(user).isNull();
    }

    @Test
    @DisplayName("Should handle User with null age")
    void testToEntity_WithNullAge() {
        // Given
        User user = new User("789", "Bob Johnson", "bob@example.com", null);

        // When
        UserEntity entity = userMapper.toEntity(user);

        // Then
        assertThat(entity).isNotNull();
        assertThat(entity.getUserId()).isEqualTo("789");
        assertThat(entity.getAge()).isNull();
    }

    @Test
    @DisplayName("Should maintain data integrity during round-trip conversion")
    void testRoundTripConversion() {
        // Given
        User originalUser = new User("999", "Alice Williams", "alice@example.com", 28);

        // When
        UserEntity entity = userMapper.toEntity(originalUser);
        User convertedUser = userMapper.toModel(entity);

        // Then
        assertThat(convertedUser).isNotNull();
        assertThat(convertedUser.getId()).isEqualTo(originalUser.getId());
        assertThat(convertedUser.getName()).isEqualTo(originalUser.getName());
        assertThat(convertedUser.getEmail()).isEqualTo(originalUser.getEmail());
        assertThat(convertedUser.getAge()).isEqualTo(originalUser.getAge());
    }
}
