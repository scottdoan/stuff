# REST vs GraphQL: What Changed?

## Summary

**What stayed the same (nothing changed):**
- ✅ Service layer (UserService.java)
- ✅ Repository layer (UserRepository.java, DynamoDbUserRepository.java)
- ✅ Domain model (User.java)
- ✅ Entity (UserEntity.java)
- ✅ Mapper (UserMapper.java)
- ✅ Configuration (DynamoDBConfig.java)
- ✅ All existing tests

**What was added:**
- ➕ GraphQL dependencies in pom.xml
- ➕ GraphQL schema (schema.graphqls)
- ➕ GraphQL controller (UserGraphQLController.java)
- ➕ GraphQL input DTOs (CreateUserInput.java, UpdateUserInput.java)
- ➕ GraphQL tests (UserGraphQLControllerTest.java)
- ➕ GraphQL configuration in application.properties

## Files Added

```
NEW FILES:
├── src/main/resources/graphql/
│   └── schema.graphqls                           # GraphQL schema definition
├── src/main/java/com/example/dynamodbapi/graphql/
│   ├── UserGraphQLController.java                # GraphQL resolver
│   ├── CreateUserInput.java                      # Input DTO for mutations
│   └── UpdateUserInput.java                      # Input DTO for updates
└── src/test/java/com/example/dynamodbapi/graphql/
    └── UserGraphQLControllerTest.java            # GraphQL tests

EXISTING FILES (UNCHANGED):
├── UserService.java          ✅ No changes
├── UserRepository.java       ✅ No changes
├── DynamoDbUserRepository.java ✅ No changes
├── User.java                 ✅ No changes
├── UserEntity.java           ✅ No changes
└── UserMapper.java           ✅ No changes
```

## Side-by-Side Code Comparison

### REST Controller vs GraphQL Controller

Both use the **same UserService**!

#### REST Controller
```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    
    private final UserService userService;
    
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable String id) {
        return userService.getUserById(id)
            .map(user -> new ResponseEntity<>(user, HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
    
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.createUser(user);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }
}
```

#### GraphQL Controller
```java
@Controller
public class UserGraphQLController {
    
    private final UserService userService;  // SAME SERVICE!
    
    @QueryMapping
    public User user(@Argument String id) {
        return userService.getUserById(id).orElse(null);
    }
    
    @MutationMapping
    public User createUser(@Argument CreateUserInput input) {
        User user = new User();
        user.setName(input.getName());
        user.setEmail(input.getEmail());
        user.setAge(input.getAge());
        return userService.createUser(user);
    }
}
```

**Notice:** Both call `userService.getUserById()` and `userService.createUser()` - same business logic!

## API Request Comparison

### Get User by ID

#### REST
```bash
GET /api/users/123

Response:
{
  "id": "123",
  "name": "John Doe",
  "email": "john@example.com",
  "age": 30
}
```

#### GraphQL
```graphql
query {
  user(id: "123") {
    id
    name
    email
    age
  }
}

Response:
{
  "data": {
    "user": {
      "id": "123",
      "name": "John Doe",
      "email": "john@example.com",
      "age": 30
    }
  }
}
```

**Key Difference:** GraphQL lets you select which fields to return!

```graphql
query {
  user(id: "123") {
    name
    email
  }
}

Response:
{
  "data": {
    "user": {
      "name": "John Doe",
      "email": "john@example.com"
    }
  }
}
```

### Create User

#### REST
```bash
POST /api/users
Content-Type: application/json

{
  "name": "Jane Smith",
  "email": "jane@example.com",
  "age": 25
}

Response: 201 Created
{
  "id": "456",
  "name": "Jane Smith",
  "email": "jane@example.com",
  "age": 25
}
```

#### GraphQL
```graphql
mutation {
  createUser(input: {
    name: "Jane Smith"
    email: "jane@example.com"
    age: 25
  }) {
    id
    name
    email
    age
  }
}

Response:
{
  "data": {
    "createUser": {
      "id": "456",
      "name": "Jane Smith",
      "email": "jane@example.com",
      "age": 25
  }
}
```

### Get Multiple Resources

#### REST (requires 3 requests)
```bash
GET /api/users/123
GET /api/users/456
GET /api/users/789
```

#### GraphQL (single request)
```graphql
query {
  user1: user(id: "123") {
    name
    email
  }
  user2: user(id: "456") {
    name
    email
  }
  user3: user(id: "789") {
    name
    email
  }
}
```

## Architecture Diagram

### Before (REST Only)
```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ HTTP REST
┌──────▼──────┐
│    REST     │
│ Controller  │
└──────┬──────┘
       │
┌──────▼──────┐
│   Service   │◄─── BUSINESS LOGIC
└──────┬──────┘
       │
┌──────▼──────┐
│ Repository  │
└──────┬──────┘
       │
┌──────▼──────┐
│  DynamoDB   │
└─────────────┘
```

### After (REST + GraphQL)
```
┌─────────────┐  ┌─────────────┐
│ REST Client │  │GraphQL Client│
└──────┬──────┘  └──────┬──────┘
       │ HTTP REST       │ HTTP POST /graphql
┌──────▼──────┐  ┌──────▼──────┐
│    REST     │  │   GraphQL   │
│ Controller  │  │  Controller │
└──────┬──────┘  └──────┬──────┘
       │                │
       └────────┬───────┘
                │
        ┌───────▼───────┐
        │    Service    │◄─── SAME BUSINESS LOGIC!
        └───────┬───────┘
                │
        ┌───────▼───────┐
        │  Repository   │
        └───────┬───────┘
                │
        ┌───────▼───────┐
        │   DynamoDB    │
        └───────────────┘
```

## Test Comparison

### REST Test
```java
@WebMvcTest(UserController.class)
class UserControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private UserService userService;
    
    @Test
    void testGetUserById() throws Exception {
        User user = new User("123", "John", "john@example.com", 30);
        when(userService.getUserById("123")).thenReturn(Optional.of(user));
        
        mockMvc.perform(get("/api/users/123"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value("John"));
    }
}
```

### GraphQL Test
```java
@GraphQlTest(UserGraphQLController.class)
class UserGraphQLControllerTest {
    
    @Autowired
    private GraphQlTester graphQlTester;
    
    @MockBean
    private UserService userService;  // SAME SERVICE!
    
    @Test
    void testGetUserById() {
        User user = new User("123", "John", "john@example.com", 30);
        when(userService.getUserById("123")).thenReturn(Optional.of(user));
        
        graphQlTester
            .document("query { user(id: \"123\") { name } }")
            .execute()
            .path("user.name").entity(String.class).isEqualTo("John");
    }
}
```

**Notice:** Both tests mock the same `UserService`!

## What This Demonstrates

### Power of Clean Architecture

1. **Business Logic Reuse**: UserService is used by both REST and GraphQL
2. **No Code Duplication**: Same logic, different API styles
3. **Easy to Add New APIs**: Could add gRPC, WebSockets, etc. the same way
4. **Testable**: Mock UserService once, test multiple API styles

### Why This Works

```
REST Controller    ┐
                   ├──► UserService ──► Repository ──► Database
GraphQL Controller ┘

Both controllers depend on the same abstraction (UserService interface),
not on implementation details.
```

## Performance Comparison

### REST
- ✅ Better HTTP caching (GET requests)
- ✅ CDN-friendly
- ❌ Over-fetching (returns all fields always)
- ❌ Under-fetching (multiple requests needed)

### GraphQL
- ✅ Request only needed fields
- ✅ Single request for complex data
- ✅ Strongly typed schema
- ❌ More complex caching
- ❌ Steeper learning curve

## When to Use Each

### Use REST for:
- Simple CRUD operations
- Public APIs consumed by many different clients
- File uploads/downloads
- When HTTP caching is critical

### Use GraphQL for:
- Mobile apps (reduce data transfer)
- Complex nested data structures
- Rapid frontend development
- Multiple clients needing different data shapes

### Use Both (Current Setup):
- **Best of both worlds!**
- Let clients choose their preferred API
- REST for simple operations
- GraphQL for complex queries
- No code duplication thanks to clean architecture

## Migration Effort

### To Add GraphQL (what we did):
- ✅ Add 3 dependencies
- ✅ Create 1 schema file
- ✅ Create 3 new classes (controller + 2 DTOs)
- ✅ Add 3 lines to application.properties
- ✅ Write tests for new controller
- ⏱️ **Total time: 2-3 hours**

### To Remove REST (if desired):
- Delete UserController.java
- Remove spring-boot-starter-web (if not needed for GraphQL)
- ⏱️ **Total time: 5 minutes**

### To Switch Database:
- Create new repository implementation (e.g., JpaUserRepository)
- **No changes needed to either REST or GraphQL controllers!**
- ⏱️ **Total time: 1-2 days**

## Conclusion

The clean architecture pattern allows you to:
1. Support multiple API styles (REST, GraphQL, gRPC, etc.)
2. Share business logic across all API styles
3. Switch persistence layers without affecting APIs
4. Test each layer independently

**The UserService doesn't know if it's being called from REST or GraphQL - and it doesn't need to!**

This is the essence of good software architecture: separation of concerns and dependency inversion.
