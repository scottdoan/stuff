# Java 21 Features Guide

This project is configured to use **Java 21**, which includes several powerful features you can leverage in your implementations.

## Why Java 21?

Java 21 is an LTS (Long Term Support) release with significant improvements:
- Better performance
- Modern language features
- Enhanced security
- Long-term support (through 2031)

## Java 21 Features You Can Use

### 1. Record Patterns (JEP 440)

Simplify pattern matching with records:

```java
public record UserRecord(String id, String email, String name) {}

// Enhanced pattern matching
public String formatUser(Object obj) {
    return switch (obj) {
        case UserRecord(String id, String email, String name) -> 
            "User %s (%s): %s".formatted(id, name, email);
        case null -> "No user";
        default -> "Unknown";
    };
}
```

### 2. Pattern Matching for Switch (JEP 441)

More expressive switch statements:

```java
public HttpStatus getStatusCode(Exception ex) {
    return switch (ex) {
        case IllegalArgumentException e -> HttpStatus.BAD_REQUEST;
        case ResourceNotFoundException e -> HttpStatus.NOT_FOUND;
        case SecurityException e -> HttpStatus.FORBIDDEN;
        default -> HttpStatus.INTERNAL_SERVER_ERROR;
    };
}
```

### 3. Virtual Threads (Project Loom)

Lightweight threads for better concurrency:

```java
@Service
public class AsyncUserService {
    
    @Async
    public void processUserAsync(User user) {
        Thread.startVirtualThread(() -> {
            // Long-running task
            processUser(user);
        });
    }
}
```

Enable virtual threads in Spring Boot:

```yaml
spring:
  threads:
    virtual:
      enabled: true
```

### 4. Sequenced Collections (JEP 431)

Better collection APIs:

```java
List<User> users = getUserList();

// Get first and last easily
User firstUser = users.getFirst();
User lastUser = users.getLast();

// Reverse easily
List<User> reversedUsers = users.reversed();
```

### 5. String Templates (Preview - JEP 430)

More readable string formatting:

```java
// Enable with --enable-preview flag
String message = STR."""
    User Details:
    - ID: \{user.getId()}
    - Email: \{user.getEmail()}
    - Status: \{user.getStatus()}
    """;
```

## Using Java 21 Features in Your Delegates

### Example: Enhanced Switch in Delegate

```java
@Service
public class UsersApiDelegateImpl implements UsersApiDelegate {
    
    @Override
    public ResponseEntity<User> updateUserStatus(String userId, String action) {
        UserStatus newStatus = switch (action.toLowerCase()) {
            case "activate" -> UserStatus.ACTIVE;
            case "deactivate" -> UserStatus.INACTIVE;
            case "suspend" -> UserStatus.SUSPENDED;
            case "pending" -> UserStatus.PENDING;
            default -> throw new IllegalArgumentException("Unknown action: " + action);
        };
        
        // Update user status
        User user = updateStatus(userId, newStatus);
        return ResponseEntity.ok(user);
    }
}
```

### Example: Virtual Threads for Async Processing

```java
@Service
public class UsersApiDelegateImpl implements UsersApiDelegate {
    
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
    
    @Override
    public ResponseEntity<Void> bulkCreateUsers(List<CreateUserRequest> requests) {
        List<CompletableFuture<User>> futures = requests.stream()
            .map(request -> CompletableFuture.supplyAsync(
                () -> createUser(request),
                executor
            ))
            .toList();
        
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        
        return ResponseEntity.accepted().build();
    }
}
```

### Example: Records for Internal DTOs

```java
// Internal record for transferring data
public record UserUpdateCommand(
    String userId,
    String firstName,
    String lastName,
    UserStatus status
) {
    // Compact constructor with validation
    public UserUpdateCommand {
        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("User ID is required");
        }
    }
}

@Service
public class UserService {
    
    public User updateUser(UserUpdateCommand command) {
        // Use the record
        return repository.findById(command.userId())
            .map(user -> {
                user.setFirstName(command.firstName());
                user.setLastName(command.lastName());
                user.setStatus(command.status());
                return repository.save(user);
            })
            .orElseThrow(() -> new ResourceNotFoundException("User", command.userId()));
    }
}
```

### Example: Sequenced Collections

```java
@Service
public class UsersApiDelegateImpl implements UsersApiDelegate {
    
    @Override
    public ResponseEntity<UserListResponse> listUsers(Integer page, Integer size, String sort) {
        List<User> users = new ArrayList<>(userStore.values());
        
        // Use sequenced collection methods
        if (users.isEmpty()) {
            return ResponseEntity.ok(emptyResponse());
        }
        
        // Get most recent user (assuming sorted by creation date)
        User mostRecentUser = users.getLast();
        log.info("Most recent user: {}", mostRecentUser.getEmail());
        
        // Reverse if needed
        if ("desc".equals(sort)) {
            users = users.reversed();
        }
        
        UserListResponse response = buildResponse(users, page, size);
        return ResponseEntity.ok(response);
    }
}
```

## Performance Benefits

### Virtual Threads in Spring Boot

Add to `application.yml`:

```yaml
spring:
  threads:
    virtual:
      enabled: true
  
  task:
    execution:
      pool:
        core-size: 10
        max-size: 100
```

Benefits:
- Handle millions of concurrent connections
- Better resource utilization
- Simpler code than reactive programming
- Compatible with existing blocking code

### Startup Time

Java 21 includes CDS (Class Data Sharing) improvements:

```bash
# Generate CDS archive
java -Xshare:dump -jar target/your-app.jar

# Run with CDS for faster startup
java -Xshare:on -jar target/your-app.jar
```

## Migration Tips from Java 17

If migrating from Java 17:

1. **Update pom.xml** ✅ (Already done)
2. **No breaking changes** - Java 21 is backward compatible
3. **Opt-in features** - Use new features gradually
4. **Test thoroughly** - Run full test suite
5. **Update dependencies** - Some libraries may have Java 21 optimizations

## Preview Features

To use preview features (like String Templates):

### Maven Configuration

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
        <source>21</source>
        <target>21</target>
        <compilerArgs>
            <arg>--enable-preview</arg>
        </compilerArgs>
    </configuration>
</plugin>

<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <configuration>
        <argLine>--enable-preview</argLine>
    </configuration>
</plugin>
```

### Runtime

```bash
java --enable-preview -jar target/your-app.jar
```

## OpenAPI Generator with Java 21

The OpenAPI Generator configuration in this project is compatible with Java 21:

```xml
<configOptions>
    <java17>false</java17>  <!-- Don't restrict to Java 17 -->
    <useJakartaEe>true</useJakartaEe>
    <useSpringBoot3>true</useSpringBoot3>
</configOptions>
```

Generated code will work with all Java 21 features.

## Best Practices

1. **Use Records for DTOs** - When you need immutable data transfer objects
2. **Pattern Matching** - Simplify type checking and casting
3. **Virtual Threads** - For high-concurrency scenarios
4. **Sequenced Collections** - When you need predictable ordering
5. **Text Blocks** - For readable multi-line strings (from Java 15)

## Example: Complete Service with Java 21 Features

```java
@Service
public class ModernUserService {
    
    // Record for internal data transfer
    public record UserCreationResult(User user, boolean isNew, String message) {}
    
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
    
    public UserCreationResult createUser(CreateUserRequest request) {
        // Pattern matching switch
        String validationResult = switch (request) {
            case CreateUserRequest r when r.getEmail() == null -> "Email required";
            case CreateUserRequest r when r.getFirstName() == null -> "First name required";
            case CreateUserRequest r when r.getLastName() == null -> "Last name required";
            default -> "valid";
        };
        
        if (!"valid".equals(validationResult)) {
            throw new IllegalArgumentException(validationResult);
        }
        
        // Virtual thread for async notification
        executor.submit(() -> sendWelcomeEmail(request.getEmail()));
        
        User user = User.builder()
            .id(UUID.randomUUID().toString())
            .email(request.getEmail())
            .firstName(request.getFirstName())
            .lastName(request.getLastName())
            .status(UserStatus.ACTIVE)
            .createdAt(OffsetDateTime.now())
            .build();
        
        return new UserCreationResult(user, true, "User created successfully");
    }
    
    private void sendWelcomeEmail(String email) {
        // Text block for email template
        String emailBody = """
            Welcome to Enterprise API!
            
            Your account has been created successfully.
            Email: %s
            
            Best regards,
            The Team
            """.formatted(email);
        
        // Send email...
        log.info("Sending welcome email: {}", emailBody);
    }
}
```

## Resources

- [Java 21 Release Notes](https://openjdk.org/projects/jdk/21/)
- [JEP 440: Record Patterns](https://openjdk.org/jeps/440)
- [JEP 441: Pattern Matching for switch](https://openjdk.org/jeps/441)
- [JEP 444: Virtual Threads](https://openjdk.org/jeps/444)
- [JEP 431: Sequenced Collections](https://openjdk.org/jeps/431)

---

**Note**: This project is configured for Java 21, but you can use it with any features from Java 17+ since Java 21 is backward compatible. Start with the basics and gradually adopt new features as needed.
