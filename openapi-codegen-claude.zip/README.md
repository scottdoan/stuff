# Enterprise API Scaffold

A **reusable Spring Boot template** that auto-generates REST controllers, service interfaces, and model classes from any OpenAPI 3.x YAML specification. The only layer you write by hand is the Repository/DAO.

## Features

| Feature | Detail |
|---|---|
| **OpenAPI → Code** | The Maven `openapi-generator-maven-plugin` reads your YAML and emits Spring MVC controller interfaces + Jakarta-validated model classes at compile time |
| **Three-layer architecture** | Controller → Service → Repository. Only the Repository is hand-written |
| **Java 21** | Records, pattern matching, sealed classes — all available |
| **Swagger UI** | Live, auto-generated API documentation at `/swagger-ui.html` |
| **Standard error envelope** | Every error response follows the same `{ code, message, details, timestamp }` shape defined in the OpenAPI spec |
| **Unit tests** | Mockito-based service tests + `@WebMvcTest` controller tests ship out of the box |
| **Javadoc** | Every hand-written class is fully documented; run `mvn javadoc:javadoc` to generate HTML |
| **H2 for dev, swap for prod** | Default datasource is H2 in-memory; replace with PostgreSQL/MySQL by changing `application.yaml` |

## Prerequisites

| Tool | Minimum Version |
|---|---|
| JDK | 21 |
| Maven | 3.8+ |
| IDE | IntelliJ IDEA or Eclipse (optional) |

## Quick Start

```bash
# 1. Clone the repository
git clone https://github.com/your-org/enterprise-api-scaffold.git
cd enterprise-api-scaffold

# 2. Generate sources from the bundled example OpenAPI spec
mvn generate-sources

# 3. Run the application
mvn spring-boot:run

# 4. Open Swagger UI in your browser
open http://localhost:8080/swagger-ui.html
```

## Project Layout

```
enterprise-api-scaffold/
├── openapi/
│   └── api.yaml                          # ← YOUR OpenAPI spec goes here
├── src/
│   ├── main/
│   │   ├── java/com/example/enterprise/api/
│   │   │   ├── EnterpriseApiApplication.java   # Boot entry point
│   │   │   ├── config/
│   │   │   │   └── OpenApiConfig.java          # Swagger metadata
│   │   │   ├── controller/
│   │   │   │   └── ProductsControllerImpl.java # Implements generated interface
│   │   │   ├── exception/
│   │   │   │   ├── ApiException.java           # Base exception
│   │   │   │   ├── GlobalExceptionHandler.java # Catches all → Error JSON
│   │   │   │   ├── InvalidRequestException.java
│   │   │   │   ├── ResourceConflictException.java
│   │   │   │   └── ResourceNotFoundException.java
│   │   │   ├── model/
│   │   │   │   └── ProductEntity.java          # JPA entity
│   │   │   ├── repository/
│   │   │   │   └── ProductRepository.java      # ← HAND-WRITE THIS
│   │   │   └── service/
│   │   │       ├── ProductService.java         # Service interface
│   │   │       └── ProductServiceImpl.java     # Maps DTO ↔ Entity
│   │   └── resources/
│   │       └── application.yaml                # DB, JPA, server config
│   └── test/
│       ├── java/…/
│       │   ├── config/GlobalExceptionHandlerTest.java
│       │   ├── controller/ProductsControllerImplTest.java
│       │   └── service/ProductServiceImplTest.java
│       └── resources/
│           └── application.yaml                # Test DB config
├── docs/
│   ├── ARCHITECTURE.md                         # Layer-by-layer deep dive
│   ├── ADDING_A_RESOURCE.md                    # Step-by-step guide for new resources
│   └── DEPLOYMENT.md                           # Production deployment notes
└── pom.xml
```

## Common Commands

| Command | What it does |
|---|---|
| `mvn generate-sources` | Regenerates controllers & models from `openapi/api.yaml` |
| `mvn test` | Runs the full unit test suite |
| `mvn javadoc:javadoc` | Generates Javadoc HTML into `target/apidocs/` |
| `mvn spring-boot:run` | Starts the embedded Tomcat server on port 8080 |
| `mvn package` | Produces an executable JAR in `target/` |

## Documentation

| File | Contents |
|---|---|
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | How the layers fit together and what the code generator produces |
| [docs/ADDING_A_RESOURCE.md](docs/ADDING_A_RESOURCE.md) | Complete walkthrough for adding a brand-new resource |
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | Switching to PostgreSQL, externalising config, containerising |

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
