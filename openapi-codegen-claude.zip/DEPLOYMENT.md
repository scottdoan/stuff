# Deployment Guide

This document covers everything you need to move from the H2 development setup to a production-grade deployment.

---

## Switching to PostgreSQL

### 1. Replace the H2 dependency

In `pom.xml`, remove:

```xml
<dependency>
    <groupId>com.h2database</groupId>
    <artifactId>h2</artifactId>
    <scope>runtime</scope>
</dependency>
```

Add PostgreSQL:

```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>
```

### 2. Update `application.yaml`

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/enterprise_db
    driver-class-name: org.postgresql.Driver
    username: ${DB_USERNAME}        # from environment variable
    password: ${DB_PASSWORD}        # from environment variable

  jpa:
    hibernate:
      ddl-auto: validate           # NEVER use create-drop in production
    show-sql: false                # disable SQL logging in production
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
```

### 3. Database migrations

For production, manage schema changes with a tool like **Flyway** or **Liquibase** instead of relying on Hibernate DDL auto.

Add Flyway:

```xml
<dependency>
    <groupId>org.flywaydb</groupId>
    <artifactId>flyway-core</artifactId>
</dependency>
```

Place migration scripts in `src/main/resources/db/migration/`:

```
V1__create_products_table.sql
V2__create_orders_table.sql
```

Spring Boot auto-detects Flyway on the classpath and runs migrations at startup.

---

## Externalising Configuration

Never commit secrets to your repository. Use one of these approaches:

| Approach | Best for |
|---|---|
| Environment variables | Containers, CI/CD pipelines |
| Spring Vault integration | Enterprise secret management |
| `.env` file (via dotenv) | Local development |
| Spring Cloud Config Server | Centralised config across microservices |

### Environment variable example

```bash
export DB_USERNAME=myuser
export DB_PASSWORD=s3cr3t
export SERVER_PORT=9090

java -jar target/enterprise-api-scaffold-1.0.0-SNAPSHOT.jar
```

In `application.yaml`, reference them with `${VAR_NAME}`:

```yaml
server:
  port: ${SERVER_PORT:8080}        # default to 8080 if not set

spring:
  datasource:
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
```

---

## Spring Profiles

Use profiles to maintain separate configurations for each environment:

| Profile | Activated by |
|---|---|
| `dev` (default) | `mvn spring-boot:run` |
| `staging` | `-Dspring.profiles.active=staging` |
| `prod` | `-Dspring.profiles.active=prod` |

Create profile-specific files:

```
src/main/resources/
├── application.yaml              # shared defaults
├── application-dev.yaml          # H2, show-sql: true
├── application-staging.yaml      # staging PostgreSQL
└── application-prod.yaml         # production PostgreSQL, logging tuned
```

Spring Boot merges them in order — profile-specific values override the defaults.

---

## Docker

### Dockerfile

```dockerfile
# Stage 1: Build
FROM eclipse-temurin:21-jdk-alpine AS builder
WORKDIR /app
COPY pom.xml .
COPY src/ src/
COPY openapi/ openapi/
RUN mvn -q package -DskipTests

# Stage 2: Runtime (minimal image)
FROM eclipse-temurin:21-jre-alpine
WORKDIR /app

# Non-root user for security
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
USER appuser

COPY --from=builder /app/target/*.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```

### docker-compose.yaml

```yaml
version: "3.9"

services:
  api:
    build: .
    ports:
      - "8080:8080"
    environment:
      SPRING_PROFILES_ACTIVE: prod
      DB_USERNAME: apiuser
      DB_PASSWORD: apipass
    depends_on:
      - postgres

  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: enterprise_db
      POSTGRES_USER: apiuser
      POSTGRES_PASSWORD: apipass
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"

volumes:
  pgdata:
```

### Build and run

```bash
docker compose build
docker compose up -d
```

---

## Production Checklist

- [ ] Replace H2 with PostgreSQL (or your chosen database)
- [ ] Set `ddl-auto: validate` and use Flyway/Liquibase for migrations
- [ ] Move all secrets to environment variables or a secret manager
- [ ] Disable `show-sql` and tune logging levels
- [ ] Use a production Spring Profile (`-Dspring.profiles.active=prod`)
- [ ] Build a Docker image and test it locally with `docker compose`
- [ ] Set appropriate JVM heap sizes (`-Xmx`, `-Xms`) for your container resources
- [ ] Place a reverse proxy (Nginx, AWS ALB, etc.) in front for TLS termination
- [ ] Configure health checks (`/actuator/health`) if deploying to Kubernetes or an orchestrator
- [ ] Add Spring Boot Actuator for monitoring if not already present:
  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-actuator</artifactId>
  </dependency>
  ```
