# Adding a New Resource

This guide walks you through adding a brand-new resource — **Orders** — to the scaffold from scratch. Every step is replicable for any future resource.

---

## Overview of Steps

| # | What | Where |
|---|---|---|
| 1 | Define the resource in OpenAPI | `openapi/api.yaml` |
| 2 | Regenerate code | `mvn generate-sources` |
| 3 | Create the JPA entity | `model/OrderEntity.java` |
| 4 | Create the repository | `repository/OrderRepository.java` |
| 5 | Create the service interface | `service/OrderService.java` |
| 6 | Implement the service | `service/OrderServiceImpl.java` |
| 7 | Implement the controller | `controller/OrdersControllerImpl.java` |
| 8 | Write tests | `test/…/service/` and `test/…/controller/` |

---

## Step 1 — Define the resource in OpenAPI

Open `openapi/api.yaml` and add:

1. A new **tag** at the top level:

```yaml
tags:
  - name: Orders
    description: Manage customer orders.
```

2. New **paths** under the `paths:` key:

```yaml
paths:
  /orders:
    get:
      tags: [Orders]
      summary: List orders
      operationId: listOrders
      # … parameters, responses …

    post:
      tags: [Orders]
      summary: Create an order
      operationId: createOrder
      # … requestBody, responses …

  /orders/{id}:
    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string
          format: uuid

    get:
      tags: [Orders]
      operationId: getOrderById
      # …

    put:
      tags: [Orders]
      operationId: updateOrder
      # …

    delete:
      tags: [Orders]
      operationId: deleteOrder
      # …
```

3. New **schemas** under `components/schemas`:

```yaml
  Order:
    type: object
    required: [id, orderId, status, createdAt]
    properties:
      id:
        type: string
        format: uuid
      orderId:
        type: string
      status:
        type: string
        enum: [PENDING, PROCESSING, SHIPPED, DELIVERED, CANCELLED]
      # … other fields …

  OrderCreateRequest:
    type: object
    required: [orderId]
    properties:
      orderId:
        type: string
      # …

  OrderUpdateRequest:
    type: object
    properties:
      status:
        type: string
        enum: [PENDING, PROCESSING, SHIPPED, DELIVERED, CANCELLED]
      # …

  OrderListResponse:
    type: object
    required: [data, meta]
    properties:
      data:
        type: array
        items:
          $ref: "#/components/schemas/Order"
      meta:
        $ref: "#/components/schemas/PaginationMeta"   # reuse existing!
```

> **Tip:** Reuse the existing `PaginationMeta`, `Error`, and shared parameters (`PageParam`, `SizeParam`) — they are defined once and referenced everywhere via `$ref`.

---

## Step 2 — Regenerate code

```bash
mvn generate-sources
```

The generator will now produce:

```
target/generated-sources/openapi/…/generated/
├── controller/
│   ├── ProductsApi.java      ← unchanged
│   └── OrdersApi.java        ← NEW
└── model/
    ├── … (existing) …
    ├── Order.java             ← NEW
    ├── OrderCreateRequest.java
    ├── OrderUpdateRequest.java
    └── OrderListResponse.java
```

---

## Step 3 — Create the JPA entity

Create `src/main/java/com/example/enterprise/api/model/OrderEntity.java`:

```java
@Entity
@Table(name = "orders")
public class OrderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String orderId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant updatedAt;

    // … @PrePersist, @PreUpdate, getters, setters …

    public enum Status {
        PENDING, PROCESSING, SHIPPED, DELIVERED, CANCELLED
    }
}
```

---

## Step 4 — Create the repository

Create `src/main/java/com/example/enterprise/api/repository/OrderRepository.java`:

```java
@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, UUID> {

    Page<OrderEntity> findByStatus(OrderEntity.Status status, Pageable pageable);

    boolean existsByOrderId(String orderId);
}
```

This is **the only layer you truly have to write**. Spring Data generates the SQL.

---

## Step 5 — Create the service interface

Create `src/main/java/com/example/enterprise/api/service/OrderService.java`:

```java
public interface OrderService {
    OrderListResponse listOrders(int page, int size, String status);
    Order createOrder(OrderCreateRequest request);
    Order getOrderById(UUID id);
    Order updateOrder(UUID id, OrderUpdateRequest request);
    void deleteOrder(UUID id);
}
```

---

## Step 6 — Implement the service

Create `src/main/java/com/example/enterprise/api/service/OrderServiceImpl.java`.

Follow the exact same pattern as `ProductServiceImpl`:

1. Inject the repository via constructor.
2. Map `OrderCreateRequest` → `OrderEntity` → `Order` (the generated DTO).
3. Throw `ResourceNotFoundException` when `findById` returns empty.
4. Throw `ResourceConflictException` when `existsByOrderId` returns true on create.
5. Annotate the class `@Transactional(readOnly = true)` and mutating methods `@Transactional`.

---

## Step 7 — Implement the controller

Create `src/main/java/com/example/enterprise/api/controller/OrdersControllerImpl.java`:

```java
@RestController
public class OrdersControllerImpl implements OrdersApi {

    private final OrderService service;

    public OrdersControllerImpl(OrderService service) {
        this.service = service;
    }

    @Override
    public ResponseEntity<OrderListResponse> listOrders(Integer page, Integer size, String status) {
        return ResponseEntity.ok(service.listOrders(
                page != null ? page : 0,
                size != null ? size : 20,
                status));
    }

    @Override
    public ResponseEntity<Order> createOrder(OrderCreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.createOrder(request));
    }

    // … getOrderById, updateOrder, deleteOrder …
}
```

---

## Step 8 — Write tests

### Service test

Copy `ProductServiceImplTest.java` as a starting template. Replace:

- `ProductRepository` → `OrderRepository`
- `ProductServiceImpl` → `OrderServiceImpl`
- Sample entity / DTO construction → Order equivalents
- Business rule assertions (e.g. orderId uniqueness)

### Controller test

Copy `ProductsControllerImplTest.java`. Replace:

- `BASE_URL` → `/api/v1/orders`
- Mock service → `OrderService`
- Request/response bodies → Order DTOs

---

## Checklist

- [ ] OpenAPI spec updated with tag, paths, and schemas
- [ ] `mvn generate-sources` run successfully
- [ ] `OrderEntity.java` created with `@PrePersist` / `@PreUpdate`
- [ ] `OrderRepository.java` created
- [ ] `OrderService.java` interface created
- [ ] `OrderServiceImpl.java` implemented with mapping + business rules
- [ ] `OrdersControllerImpl.java` implements the generated `OrdersApi`
- [ ] `OrderServiceImplTest.java` written
- [ ] `OrdersControllerImplTest.java` written
- [ ] `mvn test` passes green
- [ ] `http://localhost:8080/swagger-ui.html` shows the new Orders endpoints
