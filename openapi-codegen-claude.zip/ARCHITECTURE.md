# Architecture

This document explains how the Enterprise API Scaffold is structured, what the OpenAPI code generator produces, and how the hand-written layers connect to it.

---

## Layer Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  HTTP Request                                               │
│    GET /api/v1/products/550e8400-...                        │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  GENERATED LAYER  (auto — never edit these files)           │
│                                                             │
│   ProductsApi.java          ← Controller interface          │
│     • @GetMapping, @PostMapping, …                          │
│     • @Valid on request bodies                              │
│     • @PathVariable, @RequestParam                          │
│                                                             │
│   Product.java              ← Response model POJO           │
│   ProductCreateRequest.java ← Request model POJO            │
│   ProductUpdateRequest.java ← Request model POJO            │
│   ProductListResponse.java  ← Paginated list wrapper        │
│   PaginationMeta.java       ← Page metadata                 │
│   Error.java                ← Standard error envelope       │
└────────────────────────┬────────────────────────────────────┘
                         │  implements
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  CONTROLLER LAYER  (hand-written — thin delegation)         │
│                                                             │
│   ProductsControllerImpl.java                               │
│     • Implements ProductsApi                                │
│     • Calls ProductService                                  │
│     • Sets HTTP status codes (201, 204, etc.)               │
│     • No business logic lives here                          │
└────────────────────────┬────────────────────────────────────┘
                         │  calls
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  SERVICE LAYER  (hand-written — mapping + business logic)   │
│                                                             │
│   ProductService.java         ← Interface                   │
│   ProductServiceImpl.java     ← Implementation              │
│     • Maps generated DTOs ↔ JPA entities                    │
│     • Enforces business rules (e.g. SKU uniqueness)         │
│     • Owns @Transactional boundaries                        │
└────────────────────────┬────────────────────────────────────┘
                         │  calls
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  REPOSITORY LAYER  (hand-written — YOUR code)               │
│                                                             │
│   ProductRepository.java                                    │
│     • Extends JpaRepository                                 │
│     • Spring Data generates SQL from method names           │
│     • Add @Query for complex joins / native SQL             │
└────────────────────────┬────────────────────────────────────┘
                         │  persists
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  DATABASE  (H2 in dev / PostgreSQL in prod)                 │
└─────────────────────────────────────────────────────────────┘
```

---

## What the Code Generator Produces

When you run `mvn generate-sources`, the `openapi-generator-maven-plugin` reads `openapi/api.yaml` and writes Java source files into:

```
target/generated-sources/openapi/src/main/java/com/example/enterprise/api/generated/
├── controller/
│   └── ProductsApi.java        ← one interface per OpenAPI tag
└── model/
    ├── Product.java
    ├── ProductCreateRequest.java
    ├── ProductUpdateRequest.java
    ├── ProductListResponse.java
    ├── PaginationMeta.java
    └── Error.java
```

### Key generator settings (in `pom.xml`)

| Setting | Effect |
|---|---|
| `abstractController: true` | Generates **interfaces**, not concrete classes. You implement them yourself. |
| `useSpringBoot3: true` | Uses Jakarta namespace (`jakarta.validation`, etc.) |
| `useSpringController: true` | Emits Spring MVC annotations (`@RestController`, `@GetMapping`, …) |
| `generateTests: false` | We hand-write tests for better coverage and readability |

### What is **not** generated

| Layer | Reason |
|---|---|
| Concrete controllers | You add logging, metrics, security here |
| Service interface & impl | Business logic is yours |
| Repository | Database access is yours |
| JPA entities | They evolve independently from the API contract |
| Unit tests | Hand-written tests are more thorough |

---

## Two Model Worlds

The scaffold deliberately keeps **two separate sets of model classes**:

| Model | Package | Who owns it | Purpose |
|---|---|---|---|
| API DTOs | `generated.model` | Code generator | HTTP request/response contract |
| JPA Entities | `model` | You | Database schema |

The `ServiceImpl` is the **only** place where mapping between the two occurs. This separation means:

- You can change your database schema (add columns, rename tables) without touching the API contract.
- You can version your API (change DTOs) without changing your database.
- Generated models are regenerated freely — no hand-written code is lost.

---

## Error Handling Flow

```
Exception thrown anywhere
         │
         ▼
GlobalExceptionHandler  (@RestControllerAdvice)
         │
         ├── ApiException subclass  →  use its HttpStatus + message
         ├── MethodArgumentNotValidException  →  400, concatenate field errors
         ├── ConstraintViolationException     →  400, concatenate violations
         └── Exception (catch-all)            →  500, generic message
         │
         ▼
Standard Error JSON envelope:
  {
    "code":      <int>,
    "message":   "<string>",
    "details":   "<string or null>",
    "timestamp": "<ISO-8601>"
  }
```

---

## Transaction Management

- `ProductServiceImpl` is annotated `@Transactional(readOnly = true)` at the class level.
- Individual mutating methods (`create`, `update`, `delete`) override with `@Transactional` (read-write).
- This means read operations never hold write locks, and writes are wrapped in a single transaction automatically.

---

## Pagination Convention

All list endpoints follow the same pattern:

1. Accept `page` (zero-based) and `size` query parameters.
2. Construct a Spring `Pageable` from them.
3. Return a wrapper object with `data` (the items) and `meta` (page, size, totalElements, totalPages).

This convention is encoded in the OpenAPI spec's `ProductListResponse` + `PaginationMeta` schemas and is reused for every future list endpoint you add.
